/**
 * Title      :Drink.java
 * Description: This class contains drink class of robot program.
 * @author Zhengyu Sun
 * @version 1.0
 */

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.color.*;
import java.awt.EventQueue;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.GridLayout;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JTextField;
import java.io.*;

public class Drink extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	String choice,names;
	int a;
	private JLabel lblPleaseSelectA;
	DrinkReader drink = new DrinkReader();
	JFrame frame = new JFrame();
	
	/**
	 * Create the frame.
	 */
	public Drink() {
		
		setBounds(100, 100,700, 500);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(189,234,128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(189,234,128));
		contentPane.add(panel, BorderLayout.NORTH);
		
		 lblPleaseSelectA = new JLabel("please select a dish to order:");
		 lblPleaseSelectA.setFont(new Font("please select an option:",Font.BOLD,30));
		panel.add(lblPleaseSelectA);
		
		JPanel panel_1 = new JPanel();
		contentPane.add(panel_1, BorderLayout.CENTER);
		panel_1.setBackground(new Color(189,234,128));
		panel_1.setLayout(new GridLayout(2, 2));
		
		JButton lvcha = new JButton();
		lvcha.setBackground(new Color(155,255,155));
		lvcha.setText(this.setName(1));
		panel_1.add(lvcha);
		
		JButton hongcha = new JButton();
		hongcha.setBackground(new Color(232,164,213));
		hongcha.setText(this.setName(2));
		panel_1.add(hongcha);
		
		JButton moli = new JButton();
		moli.setBackground(new Color(251,251,168));
		moli.setText(this.setName(3));
		panel_1.add(moli);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(189,234,128));
		contentPane.add(panel_2, BorderLayout.SOUTH);
		
		JLabel lblOptionSelected = new JLabel("option selected: ");
		lblOptionSelected.setFont(new Font("option selected: ",Font.BOLD,30));
		lblOptionSelected.setBackground(new Color(189,234,128));
		panel_2.add(lblOptionSelected);
		
		textField = new JTextField();
		textField.setText(" ");
		textField.requestFocus();
		textField.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				choice = textField.getText();
			if(choice.equals(" 1")||choice.equals("1")){
			       a = drink.drinkCheck(0);
			       if(a==0){
			     lblPleaseSelectA.setText("The chioce is not available.Please select again:"); 
			     }
			       else{
			    	   PriceCal price = new PriceCal(5); 	    			  
			    lblPleaseSelectA.setText("OK! You can continue chose:");
			       }
			  }else if(choice.equals(" 2")||choice.equals("2")){
			       a = drink.drinkCheck(1);
			       if(a==0){
			     lblPleaseSelectA.setText("The chioce is not available.Please select again:");
			} else
			  {
				PriceCal price = new PriceCal(5); 	 
			    lblPleaseSelectA.setText("OK! You can continue chose:");
			  }
			  }else if(choice.equals(" 3")||choice.equals("3")){
			       a = drink.drinkCheck(2);
			       if(a==0){
			     lblPleaseSelectA.setText("The chioce is not available.Please select again:");
			      } 
			       else{
			    	   PriceCal price = new PriceCal(5); 	 
					    lblPleaseSelectA.setText("OK! You can continue chose:");
			  }
			  }else{
				textField.setText("Wrong number!");
			  }
			}
		}
		);
		panel_2.add(textField);
		textField.setColumns(10);		
		
		JButton btnThatsAll = new JButton("That's All");
		btnThatsAll.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				Jokes joke = new Jokes();
			}
		});
		panel_2.add(btnThatsAll);
		
		JButton btnGoBack = new JButton("Go back");
		btnGoBack.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				RobotGUI window = new RobotGUI();
				window.frame.setVisible(true);
			}
		});
		panel_2.add(btnGoBack);
	}
	public void go(){
		   frame.setBackground(new Color(189,234,128));
			frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			SleepMode sleep = new SleepMode();
			sleep.timeVoid();
		setBounds(100, 100, 700, 500);
	}
	public String setName(int n){
		try{
			File file = new File("..\\..\\files\\drink.txt");
			BufferedReader br = new BufferedReader(new FileReader(file));
			for(int i=0;i<n;i++){
				names = br.readLine();
			}
			br.close();
			return names;		
		}catch(IOException e){
			e.printStackTrace();
			return null;
		}
	}

}

