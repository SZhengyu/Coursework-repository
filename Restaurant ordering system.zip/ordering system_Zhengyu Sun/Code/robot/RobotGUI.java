/**
 * Title      :RobotGUI.java
 * Description: This class contains main GUI interface of robot program.
 * @author Zhengyu Sun
 * @version 1.0
 */


import java.awt.EventQueue;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.*;
import java.awt.event.ActionEvent;

public class RobotGUI {

	public JFrame frame;
	private JTextField txtYourChoice;
    String choice;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			 RobotInterface robotInterface = new RobotInterface();
			public void run() {
				try {
					
					Thread.currentThread().sleep(1000);
					robotInterface.dispose();
					RobotGUI window = new RobotGUI();
					window.frame.setVisible(true);
					window.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					SleepMode sleep = new SleepMode();
					sleep.timeVoid();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public RobotGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100,700, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(189,234,128));
		frame.getContentPane().add(panel, BorderLayout.NORTH);
		
		JLabel lblPleaseSelectAn = new JLabel("please select an option:");
		lblPleaseSelectAn.setFont(new Font("please select an option:",Font.BOLD,30));
		panel.add(lblPleaseSelectAn);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(189,234,128));
		frame.getContentPane().add(panel_1, BorderLayout.CENTER);
		panel_1.setLayout(new GridLayout(2, 2));
		
		JButton btnFish = new JButton("1. fish");
		btnFish.setBackground(new Color(155,255,155));
		panel_1.add(btnFish);
		
		JButton btnMeat = new JButton("2. meat");
		btnMeat.setBackground(new Color(232,164,213));
		panel_1.add(btnMeat);
		
		JButton btnRice = new JButton("3. rice");
		btnRice.setBackground(new Color(251,251,168));
		panel_1.add(btnRice);
		
		JButton btnNoodle = new JButton("4. noodle");
		btnNoodle.setBackground(new Color(170,170,213));
		panel_1.add(btnNoodle);
		
		JButton btnDrink = new JButton("5. drink");
		btnDrink.setBackground(new Color(200,227,227));
		panel_1.add(btnDrink);
		
		JPanel panel_2 = new JPanel();
		frame.getContentPane().add(panel_2, BorderLayout.SOUTH);
		
		JLabel lblOptionSelected = new JLabel("option selected: ");
		lblOptionSelected.setFont(new Font("option selected: ",Font.BOLD,30));
		panel_2.add(lblOptionSelected);
		panel_2.setBackground(new Color(189,234,128));
		
		txtYourChoice = new JTextField();
		txtYourChoice.requestFocus();
		txtYourChoice.setText(" ");
		
		txtYourChoice.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				choice = txtYourChoice.getText();
			if(choice.equals(" 1")||choice.equals("1")){
				Fish fish = new Fish();
				fish.setVisible(true);
				fish.go();
				SleepMode sleep = new SleepMode();
				sleep.timeVoid();
				;
			}
			else if(choice.equals(" 2")||choice.equals("2")){
				Meat meat = new Meat();
				meat.setVisible(true);
				meat.go();
				SleepMode sleep = new SleepMode();
				sleep.timeVoid();
			}
			else if(choice.equals(" 3")||choice.equals("3")){
				Rice rice = new Rice();
				rice.setVisible(true);
				rice.go();
				SleepMode sleep = new SleepMode();
				sleep.timeVoid();
			}
			else if(choice.equals(" 4")||choice.equals("4")){
				Noodle noodle = new Noodle();
				noodle.setVisible(true);
				noodle.go();
				SleepMode sleep = new SleepMode();
				sleep.timeVoid();
			}
			else if(choice.equals(" 5")||choice.equals("5")){
				Drink drink = new Drink();
				drink.setVisible(true);
				drink.go();
				SleepMode sleep = new SleepMode();
				sleep.timeVoid();
			}
			else{
				txtYourChoice.setText("wrong number!");
			}
			}
		});
		panel_2.add(txtYourChoice);
		txtYourChoice.setColumns(10);
	}

}
