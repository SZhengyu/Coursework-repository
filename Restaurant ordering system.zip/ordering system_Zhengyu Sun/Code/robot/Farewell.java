/**
 * Title      :Farewell.java
 * Description: This class contains farewell class of robot program.
 * @author Zhengyu Sun
 * @version 1.0
 */

import java.io.*;
import java.awt.color.*;
import javax.swing.*;
import java.awt.*;
public class Farewell extends JFrame {
	JPanel panel = new JPanel();
	JLabel label = new JLabel();
	JFrame myFrame = new JFrame();
	String[] strings;
public Farewell(){
	try{
		File myFile = new File("..\\..\\files\\farewell.txt");
		FileReader fileReader = new FileReader(myFile);
		BufferedReader reader = new BufferedReader(fileReader);
		String line = null;
		while((line = reader.readLine())!=null){
			strings = line.split(",");
			int i=(int)(Math.random()*4);
			label.setText(strings[i]);
			label.setFont(new Font(strings[i],Font.BOLD,50));
		}
		reader.close();
		SleepMode sleep = new SleepMode();
		sleep.timeVoid();
	}catch(Exception ex){
		ex.printStackTrace();
	}
	panel.setBackground(new Color(189,234,128));
	panel.add(label,BorderLayout.CENTER);
	myFrame.getContentPane().add(panel,BorderLayout.CENTER);
	myFrame.setBackground(new Color(189,234,128));
	myFrame.setBounds(100, 100, 700, 500);
	myFrame.setVisible(true);
	myFrame.setDefaultCloseOperation(myFrame.EXIT_ON_CLOSE);
	}
}


