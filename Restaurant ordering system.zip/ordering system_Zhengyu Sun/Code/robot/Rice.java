/**
 * Title      :Rice.java
 * Description: This class contains rice class of robot program.
 * @author Zhengyu Sun
 * @version 1.0
 */


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.color.*;
import java.io.*;
import java.awt.EventQueue;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.GridLayout;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JTextField;

public class Rice extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	String choice,names;
	int a;
	private JLabel lblPleaseSelectA;
	RiceReader rice = new RiceReader();
	JFrame frame = new JFrame();
	
	/**
	 * Create the frame.
	 */
	public Rice() {
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		 contentPane.setBackground(new Color(189,234,128));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		 panel.setBackground(new Color(189,234,128));
		contentPane.add(panel, BorderLayout.NORTH);
		
		 lblPleaseSelectA = new JLabel("please select a dish to order:");
		 lblPleaseSelectA.setFont(new Font("please select an option:",Font.BOLD,30));
		panel.add(lblPleaseSelectA);
		
		JPanel panel_1 = new JPanel();
		 panel_1.setBackground(new Color(189,234,128));
		contentPane.add(panel_1, BorderLayout.CENTER);
		panel_1.setLayout(new GridLayout(2, 3));
		
		JButton hongchang = new JButton();
		hongchang.setBackground(new Color(155,255,155));
		hongchang.setText("<html>"+this.setName(1)+"<br>"+this.setName(2));
		panel_1.add(hongchang);
		
		JButton btnHuangjinDa = new JButton();
		btnHuangjinDa.setBackground(new Color(232,164,213));
		btnHuangjinDa.setText("<html>"+this.setName(3)+"<br>"+this.setName(4));
		panel_1.add(btnHuangjinDa);
		
		JButton btnHuotuiChaofan = new JButton();
		btnHuotuiChaofan.setBackground(new Color(251,251,168));
		btnHuotuiChaofan.setText("<html>"+this.setName(5)+"<br>"+this.setName(6));
		panel_1.add(btnHuotuiChaofan);
		
		JButton btnQingjiaoNiurou = new JButton();
		btnQingjiaoNiurou.setBackground(new Color(170,170,213));
		btnQingjiaoNiurou.setText("<html>"+this.setName(7)+"<br>"+this.setName(8));
		panel_1.add(btnQingjiaoNiurou);
		
		JButton btnShengcaiNiurou = new JButton();
		btnShengcaiNiurou.setBackground(new Color(200,227,227));
		btnShengcaiNiurou.setText("<html>"+this.setName(9)+"<br>"+this.setName(10));
		panel_1.add(btnShengcaiNiurou);
		
		JButton btnShachaNiu = new JButton();
		btnShachaNiu.setBackground(new Color(208,208,208));
		btnShachaNiu.setText("<html>"+this.setName(11)+"<br>"+this.setName(12));
		panel_1.add(btnShachaNiu);
		
		JPanel panel_2 = new JPanel();
		 panel_2.setBackground(new Color(189,234,128));
		contentPane.add(panel_2, BorderLayout.SOUTH);
		
		JLabel lblOptionSelected = new JLabel("option selected: ");
		lblOptionSelected.setFont(new Font("option selected: ",Font.BOLD,30));
		panel_2.add(lblOptionSelected);
		
		textField = new JTextField();
		textField.setText(" ");
		textField.requestFocus();
		
		textField.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				choice = textField.getText();
			if(choice.equals(" 1")||choice.equals("1")){
			       a = rice.riceCheck(0);
			       if(a==0){
			     lblPleaseSelectA.setText("The chioce is not available.Please select again:"); 
			     }
			       else{
			    	   PriceCal price = new PriceCal(10); 	    			  
			    lblPleaseSelectA.setText("OK! You can continue chose:");
			       }
			  }else if(choice.equals(" 2")||choice.equals("2")){
			       a = rice.riceCheck(1);
			       if(a==0){
			     lblPleaseSelectA.setText("The chioce is not available.Please select again:");
			} else
			  {
				PriceCal price = new PriceCal(10); 	 
			    lblPleaseSelectA.setText("OK! You can continue chose:");
			  }
			  }else if(choice.equals(" 3")||choice.equals("3")){
			       a = rice.riceCheck(2);
			       if(a==0){
			     lblPleaseSelectA.setText("The chioce is not available.Please select again:");
			      } 
			       else{
			    	   PriceCal price = new PriceCal(10); 	 
					    lblPleaseSelectA.setText("OK! You can continue chose:");
			  }
			  }else if(choice.equals(" 4")||choice.equals("4")){
			       a = rice.riceCheck(3);
			       if(a==0){
			     lblPleaseSelectA.setText("The chioce is not available.Please select again:");
			      } 
			       else{
			    	   PriceCal price = new PriceCal(10); 	 
					    lblPleaseSelectA.setText("OK! You can continue chose:");
			  }
			 }else if(choice.equals(" 5")||choice.equals("5")){
			       a = rice.riceCheck(4);
			       if(a==0){
			     lblPleaseSelectA.setText("The chioce is not available.Please select again:");
			      } 
			       else{
			    	   PriceCal price = new PriceCal(10); 	 
					    lblPleaseSelectA.setText("OK! You can continue chose:");
			  }
			 }else if(choice.equals(" 6")||choice.equals("6")){
			       a = rice.riceCheck(5);
			       if(a==0){
			     lblPleaseSelectA.setText("The chioce is not available.Please select again:");
			      } 
			       else{
			    	   PriceCal price = new PriceCal(10); 	 
					    lblPleaseSelectA.setText("OK! You can continue chose:");
			  }
			       }else{
				textField.setText("Wrong number!");
			  }
			}
		}
		);
		panel_2.add(textField);
		textField.setColumns(10);		
		
		JButton btnThatsAll = new JButton("That's All");
		btnThatsAll.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				Jokes joke = new Jokes();
			}
		});
		panel_2.add(btnThatsAll);
		
		JButton btnGoBack = new JButton("Go back");
		btnGoBack.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				RobotGUI window = new RobotGUI();
				window.frame.setVisible(true);
			}
		});
		panel_2.add(btnGoBack);
	}
	public void go(){
		   frame.setBackground(new Color(189,234,128));
			frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			SleepMode sleep = new SleepMode();
			sleep.timeVoid();
		setBounds(100, 100, 700, 500);
	}
	public String setName(int n){
		try{
			File file = new File("..\\..\\files\\RiceDishes.txt");
			BufferedReader br = new BufferedReader(new FileReader(file));
			for(int i=0;i<n;i++){
				names = br.readLine();
			}
			br.close();
		
			return names;		
		}catch(IOException e){
			e.printStackTrace();
			return null;
		}
	}
}
