/**
 * Title      :Fish.java
 * Description: This class contains fish class of robot program.
 * @author Zhengyu Sun
 * @version 1.0
 */


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.io.*;

public class Fish extends JFrame {
	private JPanel contentPane;
	private JTextField textField;
	String choice;
	int a;
	private JLabel lblPleaseSelectA;
	FishReader fish = new FishReader();
	String names; 
	JFrame frame = new JFrame();
	/**
	 * Create the frame.
	 */
	public Fish() {
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setBackground(new Color(189,234,128));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(189,234,128));
		contentPane.add(panel, BorderLayout.NORTH);
		
		
	    lblPleaseSelectA = new JLabel("please select a dish to order:");
	    lblPleaseSelectA.setFont(new Font("please select an option:",Font.BOLD,30));
		panel.add(lblPleaseSelectA);
		
		JPanel panel_1 = new JPanel();
		contentPane.add(panel_1, BorderLayout.CENTER);
		panel_1.setBackground(new Color(189,234,128));
		panel_1.setLayout(new GridLayout(2, 2));
		
		JButton luyu = new JButton();
		luyu.setBackground(new Color(155,255,155));
		luyu.setText(this.setName(1));
		panel_1.add(luyu);
		
		JButton xiamen = new JButton();
		xiamen.setBackground(new Color(232,164,213));
		xiamen.setText(this.setName(2));
		panel_1.add(xiamen);
		
		JButton sichuan = new JButton();
		sichuan.setBackground(new Color(251,251,168));
		sichuan.setText(this.setName(3));
		panel_1.add(sichuan);
		
		JPanel panel_2 = new JPanel();
		contentPane.add(panel_2, BorderLayout.SOUTH);
		
		JLabel lblOptionSelected = new JLabel("option selected: ");
		lblOptionSelected.setFont(new Font("option selected: ",Font.BOLD,30));
		panel_2.setBackground(new Color(189,234,128));
		panel_2.add(lblOptionSelected);
		
		textField = new JTextField();
		textField.setText(" ");
		textField.requestFocus();
		textField.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				choice = textField.getText();
			if(choice.equals(" 1")||choice.equals("1")){
			       a = fish.fishCheck(0);
			       if(a==0){
			     lblPleaseSelectA.setText("The chioce is not available.Please select again:"); 
			     }
			       else{
			    PriceCal price = new PriceCal(10); 	   			  
			    lblPleaseSelectA.setText("OK!  You can continue chose:");
			       }
			  }else if(choice.equals(" 2")||choice.equals("2")){
			       a = fish.fishCheck(1);
			       if(a==0){
			     lblPleaseSelectA.setText("The chioce is not available.Please select again:");
			} else
			  {
				 PriceCal price = new PriceCal(10);
			    lblPleaseSelectA.setText("OK!  You can continue chose:");
			  }
			  }else if(choice.equals(" 3")||choice.equals("3")){
			       a = fish.fishCheck(2);
			       if(a==0){
			     lblPleaseSelectA.setText("The chioce is not available.Please select again:");
			      } 
			       else{
			    	   PriceCal price = new PriceCal(10);
					    lblPleaseSelectA.setText("OK!  You can continue chose:");
			  }
			  }else{
				textField.setText("Wrong number!");
			  }
			}
		}
		);
		panel_2.add(textField);
		textField.setColumns(10);		
		
		JButton btnThatsAll = new JButton("That's All");
		btnThatsAll.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				Jokes joke = new Jokes();
			//	frame.hide();
			}
		});
		panel_2.add(btnThatsAll);
		
		JButton btnGoBack = new JButton("Go back");
		btnGoBack.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				RobotGUI window = new RobotGUI();
				window.frame.setVisible(true);
			}
		});
		panel_2.add(btnGoBack);
	}
	public void go(){
		   frame.setBackground(new Color(189,234,128));
			frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			SleepMode sleep = new SleepMode();
			sleep.timeVoid();
		setBounds(100, 100, 700, 500);
	}
	public String setName(int n){
		try{
			File file = new File("..\\..\\files\\FishDishes.txt");
			BufferedReader br = new BufferedReader(new FileReader(file));
			for(int i=0;i<n;i++){
				names = br.readLine();
			}
			br.close();
		
			return names;		
		}catch(IOException e){
			e.printStackTrace();
			return null;
		}
	}
}
