
import java.io.*;
public class PriceCal {
File file = new File("totalPrice.txt");
int[] num = new int[50];
public PriceCal(int n){
	String price = String.valueOf(n);
	try{
    FileWriter fw = new FileWriter("..\\..\\files\\totalPrice.txt",true);
    
    fw.write(price);
    fw.write(",");
    fw.close();
}catch(IOException e){
	e.printStackTrace();
}
}
public PriceCal(){};
public int totalPrice(){
	try{
		File file = new File("..\\..\\files\\totalPrice.txt");
		BufferedReader br = new BufferedReader(new FileReader(file));
		String price = br.readLine();
		String[] totalPrice = price.split(",");
		int sum = 0;
		for(int i=0;i<totalPrice.length;i++){
			num[i]=Integer.parseInt(totalPrice[i]);
			sum=sum+num[i];	
		}
		br.close();
		return sum;
	}catch(IOException ex){
		ex.printStackTrace();
		return -1;
	}
}
}