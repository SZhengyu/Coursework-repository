

import java.io.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Jokes extends JFrame {
	JFrame myFrame = new JFrame();
	String[] strings;
	String names;
	private  JPanel panel = new JPanel();
	private  JButton btnStopJokes ;
	private  JButton btnCheckout;
	private  JPanel panel_1 = new JPanel();
	private  JLabel lblJokes = new JLabel("");
	private  JButton btnGoToPay;
	PriceCal price ;
	private  JButton btnOrderDishes = new JButton("Order dishes");

	
public Jokes(){
	try{
		File myFile = new File("..\\..\\files\\jokes.txt");
		FileReader fileReader = new FileReader(myFile);
		BufferedReader reader = new BufferedReader(fileReader);
		String line = null;
		int i=(int)(Math.random()*4);
		if(i==0){
			lblJokes.setText("<html>"+this.setName(1)+"<br>"+this.setName(2));
			lblJokes.setFont(new Font(this.setName(1),Font.BOLD,30));
			
		}else if(i==1){
			lblJokes.setText("<html>"+this.setName(3)+"<br>"+this.setName(4));
			lblJokes.setFont(new Font(this.setName(3),Font.BOLD,30));
		
		}else if(i==2){
			lblJokes.setText("<html>"+this.setName(5)+"<br>"+this.setName(6));
			lblJokes.setFont(new Font(this.setName(5),Font.BOLD,30));
		
		}else if(i==3){
			lblJokes.setText("<html>"+this.setName(7)+"<br>"+this.setName(8));
			lblJokes.setFont(new Font(this.setName(7),Font.BOLD,30));
			
		}
		reader.close();
		SleepMode sleep = new SleepMode();
		sleep.timeVoid();
	}catch(Exception ex){
		ex.printStackTrace();
	}
	myFrame.setBounds(100, 100,700, 500);
	myFrame.setVisible(true);
	myFrame.setDefaultCloseOperation(myFrame.EXIT_ON_CLOSE);
	myFrame.getContentPane().setLayout(new BorderLayout(0, 0));
	myFrame.getContentPane().add(panel, BorderLayout.NORTH);
	
	btnStopJokes = new JButton("Stop jokes");
	btnStopJokes.setBackground(new Color(170,170,213));
	btnStopJokes.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
			lblJokes.setText("");
		}
	});
	panel.add(btnStopJokes);	
	
	btnOrderDishes.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
			RobotGUI window = new RobotGUI();
			window.frame.setVisible(true);
		}
	});
	btnOrderDishes.setBackground(new Color(170,170,213));
	
	panel.add(btnOrderDishes);
	panel.setBackground(new Color(189,234,128));
	btnCheckout = new JButton("Check-out");
	btnCheckout.setBackground(new Color(170,170,213));
	panel.add(btnCheckout);
	btnCheckout.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
			price = new PriceCal();
			int price1 = price.totalPrice();
			lblJokes.setText("the total price is:   "+price1+"  yuan");
	}
	});
	myFrame.getContentPane().add(panel_1, BorderLayout.CENTER);
	panel_1.setLayout(new BorderLayout(0, 0));
	
	panel_1.add(lblJokes, BorderLayout.NORTH);
	panel_1.setBackground(new Color(189,234,128));
	btnGoToPay = new JButton("go to pay");
	btnGoToPay.setBackground(new Color(170,170,213));
	btnGoToPay.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
		new Farewell();
		}
	});
	panel_1.add(btnGoToPay, BorderLayout.SOUTH);
	}
public String setName(int n){
	try{
		File file = new File("..\\..\\files\\jokes.txt");
		BufferedReader br = new BufferedReader(new FileReader(file));
		for(int i=0;i<n;i++){
			names= br.readLine();
		}
		br.close();
		return names;		
	}catch(IOException e){
		e.printStackTrace();
		return null;
	}
}
}


