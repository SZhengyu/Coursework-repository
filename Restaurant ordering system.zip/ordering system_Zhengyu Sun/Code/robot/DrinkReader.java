

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.BufferedWriter;
import java.io.FileWriter;

public class DrinkReader {
	String[] strings;
	String strings2;
	String line;
	int number;
	int i;
	public DrinkReader(){
	};
	public int drinkCheck(int n){
		File myFile = new File("..\\..\\files\\drinkRecorder.txt");		
		try{
			BufferedReader br = new BufferedReader(new FileReader(myFile));	
			line = br.readLine();
            strings = line.split(",");
            number = Integer.parseInt(strings[n]);
            br.close(); 
		}catch(Exception ex){
    			ex.printStackTrace();
    		}	
            if(number>0){
            number--;
            strings2 = String.valueOf(number);
            strings[n]=strings2;
			try{
			BufferedWriter bw = new BufferedWriter(new FileWriter(myFile));
			for(i=0;i<strings.length;i++){
				bw.write(strings[i]);
				bw.write(",");
			}			
		    bw.close();
		    return 1;
			}catch(Exception ex){
			ex.printStackTrace();
			return 1;
		}
            }
			else{
            	return 0;
            }
			}	
}
