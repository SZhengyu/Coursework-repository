/**
 * Title      :RobotInterface.java
 * Description: This class contains welcome  interface of robot program.
 * @author Zhengyu Sun
 * @version 1.0
 */

import java.io.*;
import javax.swing.*;
import java.awt.*;
public class RobotInterface extends Frame {
		Frame myFrame = new JFrame();
		JPanel panel = new JPanel();
		JLabel label = new JLabel();
	    String[] strings;
		
public RobotInterface(){
	try{
		label.setBackground(new Color(189,234,128)); 
		panel.setBackground(new Color(189,234,128));
		File myFile = new File("..\\..\\files\\WelcomeMessages.txt");
		FileReader fileReader = new FileReader(myFile);
		BufferedReader reader = new BufferedReader(fileReader);
		String line = null;
		while((line = reader.readLine())!=null){
			strings = line.split(",");
			int i=(int)(Math.random()*4);			
			label.setText(strings[i]);
			label.setFont(new Font(strings[i],Font.BOLD,50));
		    panel.add(label,BorderLayout.CENTER);
			myFrame.add(panel,BorderLayout.CENTER);
	        myFrame.setBounds(100, 100, 700, 500);
	       myFrame.setVisible(true);
		}
		reader.close();
	}catch(Exception ex){
		ex.printStackTrace();
	}	
	}
/*public static void main(String[] args){
	new RobotInterface();
}*/
}




