/**
 * Title      :SleepMode.java
 * Description: This class contains sleep mode of robot program.
 * @author Zhengyu Sun
 * @version 1.0
 */

import java.util.Timer;
import java.awt.font.*;
import java.awt.color.*;
import java.util.TimerTask;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class SleepMode {   
	JLabel label =new JLabel(); 
	JFrame frame = new JFrame(); 
    public void timeVoid(){
        final Timer timer = new Timer(); 
       
        TimerTask tt=new TimerTask() { 
            @Override
            public void run() {
            	label.setText("Sleeping......");
            	Font f = new Font("Sleeping......",Font.BOLD,50);
            	label.setFont(f);
            	frame.setBackground(new Color(189,234,128));         
             frame.getContentPane().add(label);        
             frame.setBounds(100, 100,700, 500);
             frame.setVisible(true);
             label.addMouseMotionListener(new MouseMotionListener(){
         		public void mouseMoved(MouseEvent e){	
         			frame.dispose();;
         		}
         		public void mouseDragged(MouseEvent e){
         			}
         	});
           
                timer.cancel();
            }
        };
        timer.schedule(tt, 30000);
    }

}
