package entity;

import java.io.Serializable;

import View.Screen.*;
// information for each screen
public class Screen implements Serializable{
	int id;

	private static final long serialVersionUID = 1L;

	int seat[]; //store the information for each seat. 1=>booked    0=> no people book it
	public int type;
	int rest;
	int total;
	
	public Screen(int id, int type){
		this.id = id;
		this.type = type;
		if (type == 1)
			this.total = 32; //the screen have 32 seat in total
		else if(type == 2)
			this.total = 26;
		else 
			this.total = 32;
	    rest = total;
		this.seat = new int[total];
		for(int i = 0; i < total; i++) // set all seat unbooked
			seat[i] =0;
	}
	
	public void deScreen(int seatNo){
		if (seat[seatNo] == 0 )
		{
			rest--;
			seat[seatNo] = 1;
		}
	}
	
	public void reScreen(int seatNo){
		if (seat[seatNo] == 1 )
		{
			System.out.println("return ticket successfully");
			rest++;
			seat[seatNo] = 0;
			
		}
	}
	
	public void show(){
		if (type == 1){
			//Screen1_view ss = new Screen1_view(this);
		}
			
		else if (type == 2){
			//Screen2_view ss = new Screen2_view(this);
		}
		else{
			//Screen3_view ss = new Screen3_view(this);
		}
		
	}
	
	
	
	
	
	
	public int getId() {
		return id;
	}

	
	public void setId(int id) {
		this.id = id;
	}
	
	public int[] getSeat() {
		return seat;
	}

	public void setSeat(int[] seat) {
		this.seat = seat;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public int getRest() {
		return rest;
	}

	public void setRest(int rest) {
		this.rest = rest;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}


}
