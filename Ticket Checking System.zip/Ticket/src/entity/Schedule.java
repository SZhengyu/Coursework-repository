package entity;
import java.io.Serializable;
import java.util.Date;

public class Schedule implements Serializable{
	int id;
	//static final long serialVersionUID = 2L;

	Screen screen;  // in which screen, screen have the information for seat(booked or not)
	Film film;         // which film will be show in this screen in this schedule
	Date date;       // the time for this film( example 10:30 )
	
	public Schedule(Screen s, Film f, Date d){
		this.id = 0;
		this.screen = s;
		this.film = f;
		this.date = d;
	}
	
	
	
	
	
	

	
	
	
	
	
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Screen getScreen() {
		return screen;
	}
	public void setScreen(Screen screen) {
		this.screen = screen;
	}
	public Film getFilm() {
		return film;
	}
	public void setFilm(Film film) {
		this.film = film;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	
	public String toString(){
		return "Time: "+ this.getDate() + "\n Film: " + this.getFilm().getName() +  "Type \n : " + this.getScreen().getType();
	}

}
