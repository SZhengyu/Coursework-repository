package entity;

import java.io.Serializable;
import java.text.DecimalFormat;
import java.util.Date;

import service.ManagerService;

public class Ticket implements Serializable{
	static final long serialVersionUID = 3L;
	String idnum;
	int schid; // schedule id, can use this to find the schedule information for this ticket, like time, film, screen
	String seatid; // the particular seat id for this ticket, combining with schedule can get all information about the ticket
	int seatnum;
	int printid; // reserve for future ticket id that print on the real ticket(with random number)
	int type; // 0 => normal type, 1=> student type..... You can choose it by yourself, i haven't covered it yet.
	double price; // the original price, without any discount
	double discount; // times with price, getting the real price
	int studentid; // if needs, it depends
	boolean pay;
	
	public Ticket(int schid, String seatid, int seatnum){
		this.schid = schid;
		//this.seatid = Integer.parseInt(seatid);
		this.seatnum = seatnum;
		this.seatid = seatid;
		this.price = 16;
		this.pay = false;
	}
	
	
	
	
	public boolean isPay() {
		return pay;
	}

	public void setPay() {
		this.pay = true;
	}
	
	public void refound(){
		this.pay = false;
	}
	
	public String getIdnum() {
		return idnum;
	}
	public void setIdnum(String id) {
		this.idnum = id;
	}
	
	public int getPrintid() {
		return printid;
	}
	public void setPrintid(int printid) {
		this.printid = printid;
	}
	
	public int getSchid() {
		return schid;
	}
	public void setSchid(int schid) {
		this.schid = schid;
	}
	public String getSeatid() {
		return seatid;
	}
	public void setSeatid(String seatid) {
		this.seatid = seatid;
	}
	
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double d) {
		this.price = d;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	public int getStudentid() {
		return studentid;
	}
	public void setStudentid(int studentid) {
		this.studentid = studentid;
	}

	public int getSeatnum() {
		return seatnum;
	}

	public void setSeatnum(int seatnum) {
		this.seatnum = seatnum;
	}

	

}
