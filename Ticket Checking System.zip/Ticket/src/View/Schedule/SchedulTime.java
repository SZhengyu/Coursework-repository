package View.Schedule;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.util.*;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JSpinner;
import javax.swing.SpinnerDateModel;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class SchedulTime {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SchedulTime window = new SchedulTime();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SchedulTime() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1000, 750);
		frame.getContentPane().setBackground(new Color(255, 250, 205));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
		JLabel lblDeleteFilm = new JLabel("Pick time");
		 lblDeleteFilm.setFont(new Font("Verdana", Font.BOLD, 20));
		 lblDeleteFilm.setBounds(378, 17, 162, 32);
		 frame.getContentPane().add(lblDeleteFilm);
		
		JSpinner timeSpinner = new JSpinner( new SpinnerDateModel() );
		timeSpinner.setBounds(756, 68, 90, 87);
		JSpinner.DateEditor timeEditor = new JSpinner.DateEditor(timeSpinner, "HH:mm");
		timeSpinner.setEditor(timeEditor);
		timeSpinner.setValue(new Date());
		SpinnerDateModel s = (SpinnerDateModel)timeSpinner.getModel();
		
		frame.getContentPane().setLayout(null);
		frame.getContentPane().add(timeSpinner);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				Date d = (Date) s.getValue();
				
			}
		});
		btnSubmit.setBounds(685, 579, 181, 39);
		frame.getContentPane().add(btnSubmit);
	}
}
