package View.Schedule;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JToggleButton;
import javax.swing.SpinnerDateModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import View.Film.MFilm;
import entity.Film;
import entity.Schedule;
import entity.Screen;
import service.ManagerService;
import test.Administrator;
import test.Welcome;

import javax.swing.JRadioButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Scheduleview {

	private JFrame frame;

	/**
	 * Launch the application.*/
	 
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Scheduleview window = new Scheduleview();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Scheduleview() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		Film pick;
		frame.getContentPane().setLayout(null);
		frame.setBounds(100, 100, 1000, 750);
		frame.getContentPane().setBackground(new Color(255, 250, 205));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JTable table_2;
		JLabel nosee = new JLabel();
		nosee.setVisible(false);
		JLabel lblL;
		JLabel lblFilm = new JLabel("Film:");
		lblFilm.setBounds(756, 91, 90, 32);
		frame.getContentPane().add(lblFilm);
		ManagerService m = new ManagerService();
		ArrayList <Film> f = m.getFilms();
		
		Object[][] data;	
		data = new Object[(f.size())][5];
		for(int i = 0; i < f.size(); i++){
			data[i][0] = f.get(i).getId()+"";
			data[i][1] = f.get(i).getName();
			data[i][2] = f.get(i).getDuration()+"min";
			data[i][3] =new ImageIcon(f.get(i).getImage());
			//data[i][3] = f.get(i).get();
			data[i][4] = f.get(i).getInfo();
			
			}
		
	
		String[] columnNames = {"Film ID",
                "Name",
                "Duration",
                "Image",
                "Infomation"};
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment( SwingConstants.CENTER );
		DefaultTableModel tableModel = new DefaultTableModel(data, columnNames) {
		    @Override
		    public boolean isCellEditable(int row, int column) {
		       //all cells false
		       return false;
		    }
		};
		frame.getContentPane().setLayout(null);
		table_2 = new JTable(tableModel){
            public Class<? extends Object> getColumnClass(int column)
            {
                return getValueAt(1, column).getClass();
            }
        };
		table_2.setFont(new Font("Verdana", Font.PLAIN, 18));
		table_2.setBackground(SystemColor.info);
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(38, 62, 704, 516);
		frame.getContentPane().add(scrollPane);
		scrollPane.setViewportView(table_2);
		 table_2.setRowHeight(150);
		 
		 lblL = new JLabel("l2");
		 lblL.setForeground(new Color(255, 250, 205));
		 lblL.setBounds(711, 6, 133, 37);
		 frame.getContentPane().add(lblL);
		 
		 JLabel lblDeleteFilm = new JLabel("Double click to pick a film & adjust the time and screen to add schedule");
		 lblDeleteFilm.setFont(new Font("Verdana", Font.BOLD, 20));
		 lblDeleteFilm.setBounds(84, 17, 841, 32);
		 frame.getContentPane().add(lblDeleteFilm);
		 
		 JButton btnBack = new JButton("Back");
		 btnBack.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent arg0) {
		 	}
		 });
		 btnBack.addMouseListener(new MouseAdapter() {
		 	@Override
		 	public void mouseClicked(MouseEvent e) {
		 		showschview show = new showschview();	
				frame.setVisible(false);
		 		
		 	}
		 });
		 
		 btnBack.setBounds(609, 607, 121, 51);
		 frame.getContentPane().add(btnBack);
		 
		 table_2.getColumn("Name").setMaxWidth(200);
		 table_2.getColumn("Film ID").setMaxWidth(50);
		 table_2.getColumn("Duration").setMaxWidth(80);
		 table_2.setDefaultRenderer(Object.class, centerRenderer);	 
		 table_2.addMouseListener(new MouseAdapter() {
			  public void mouseClicked(MouseEvent e) {
			    if (e.getClickCount() == 2) {
			      JTable target = (JTable)e.getSource();
			      int row = target.getSelectedRow();
			  	  String fid = table_2.getValueAt(row,0).toString();
			  	  lblFilm.setText("Film: " + fid);
			  	  nosee.setName(fid);
			  	  
			  	  
			      
			      // do some action if appropriate column
			    }
			  }
			});
		 
		 JSpinner timeSpinner = new JSpinner( new SpinnerDateModel() );
			timeSpinner.setBounds(756, 176, 90, 87);
			JSpinner.DateEditor timeEditor = new JSpinner.DateEditor(timeSpinner, "HH:mm");
			timeSpinner.setEditor(timeEditor);
			timeSpinner.setValue(new Date());
			SpinnerDateModel s = (SpinnerDateModel)timeSpinner.getModel();
			
			frame.getContentPane().setLayout(null);
			frame.getContentPane().add(timeSpinner);
				
			JLabel lblTime = new JLabel("Time:");
			lblTime.setBounds(756, 150, 72, 18);
			frame.getContentPane().add(lblTime);
			
			JRadioButton t1 = new JRadioButton("Screen1");
			t1.setSelected(true);
			t1.setBounds(756, 341, 90, 27);
			frame.getContentPane().add(t1);
			
			JRadioButton t2 = new JRadioButton("Screen2");
			t2.setBounds(756, 373, 90, 27);
			frame.getContentPane().add(t2);
			
			JRadioButton t3 = new JRadioButton("Screen3");
			t3.setBounds(756, 405, 90, 27);
			frame.getContentPane().add(t3);
			
			ButtonGroup bgroup1 = new ButtonGroup();
			bgroup1.add(t1);
			bgroup1.add(t2);
			bgroup1.add(t3);
		
			
			
			JButton btnSubmit = new JButton("Submit");
			btnSubmit.setBounds(442, 607, 121, 51);
			frame.getContentPane().add(btnSubmit);
			btnSubmit.addMouseListener(new MouseAdapter() {

				public void mouseClicked(MouseEvent arg0) {
					int type = 0;
					if (t1.isSelected()){
						type =1;		
					}
					else if (t2.isSelected()){
						type = 2;
					}
					else
						type = 3;
					
					Screen scr = new Screen(1,type);
					Film fff =m.getFilm(nosee.getName());
					Date d = (Date) s.getValue();
					Schedule sch = new Schedule(scr,fff,d);
					m.addSch(sch);
					m.saveSch();
					frame.setVisible(false);
					showschview show = new showschview();		
				}
			});
			frame.setVisible(true);
	}
}
