package View.Schedule;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import entity.Schedule;
import service.ManagerService;
import test.Administrator;

public class showschview {

	private JFrame frame;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					showschview window = new showschview();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public showschview() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setLayout(null);
		
		JLabel lblSchedule = new JLabel("Schedule");
		lblSchedule.setBounds(180, 13, 362, 56);
		frame.getContentPane().add(lblSchedule);
		
		table = new JTable();
		frame.getContentPane().add(table);
		frame.setBounds(100, 100, 1000, 750);
		frame.getContentPane().setBackground(new Color(255, 250, 205));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		ManagerService m = new ManagerService();
		ArrayList<Schedule> schs = m.getSchs();
		Object data[][] = new Object[(schs.size())][4];
		for(int i = 0; i < schs.size(); i++){
			data[i][0] = schs.get(i).getId()+"";
			data[i][1] = schs.get(i).getFilm().getName();
			data[i][2] = new SimpleDateFormat("HH:mm").format(schs.get(i).getDate());
			data[i][3] = schs.get(i).getScreen().getType()+"";
		
			}
		
	
		String[] columnNames = {"ID","Film",
                "Time",
                "Screen"};
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment( SwingConstants.CENTER );
		DefaultTableModel tableModel = new DefaultTableModel(data, columnNames) {
		    @Override
		    public boolean isCellEditable(int row, int column) {
		       //all cells false
		       return false;
		    }
		};
		frame.getContentPane().setLayout(null);
		table = new JTable(tableModel){
            public Class<? extends Object> getColumnClass(int column)
            {
                return getValueAt(1, column).getClass();
            }
        };
		table.setFont(new Font("Verdana", Font.PLAIN, 18));
		table.setBackground(SystemColor.info);
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(90, 118, 662, 382);
		frame.getContentPane().add(scrollPane);
		scrollPane.setViewportView(table);
		
		 table.setRowHeight(100);
		 table.getColumn("ID").setMaxWidth(500);
		 table.getColumn("Film").setMaxWidth(500);
		 table.getColumn("Time").setMaxWidth(500);
		 table.getColumn("Screen").setMaxWidth(300);
		 table.setDefaultRenderer(Object.class, centerRenderer);	 
		 /*table.addMouseListener(new MouseAdapter() {
			  public void mouseClicked(MouseEvent e) {
			    if (e.getClickCount() == 2) {
			    	JTable target1 = (JTable)e.getSource();
				     int row = target1.getSelectedRow();
				  	 String fid = table.getValueAt(row,0).toString();
				  	 m.deleSch(fid);
				  	 frame.setVisible(false);
				  	showschview show = new showschview();		
				  	 
			      // do some action if appropriate column
			    }
			  }
			});*/
		 
		 JButton btnBack = new JButton("Back");
		 btnBack.addMouseListener(new MouseAdapter() {
		 	@Override
		 	public void mouseClicked(MouseEvent e) {
		 		frame.setVisible(false);
		 		Administrator window = new Administrator();
		 	}
		 });
		 btnBack.setBounds(793, 567, 123, 50);
		 frame.getContentPane().add(btnBack);
		 
		 JButton btnAddSchedule = new JButton("Add schedule");
		 btnAddSchedule.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					JButton t = (JButton)e.getSource();
					Scheduleview window = new Scheduleview();
					frame.setVisible(false);
		 }});
		 btnAddSchedule.setBounds(467, 567, 123, 50);
		 frame.getContentPane().add(btnAddSchedule);
		 
		 JButton btnDeleteSchedule = new JButton("Delete Schedule");
		 btnDeleteSchedule.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					JButton t = (JButton)e.getSource();
					DeleteSch window = new DeleteSch();
					frame.setVisible(false);
		 }});
		 btnDeleteSchedule.setBounds(629, 567, 123, 50);
		 frame.getContentPane().add(btnDeleteSchedule);
		 
		 
		 frame.setVisible(true);
		 
		 
		 
		 
	}
}
