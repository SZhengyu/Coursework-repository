package View.Film;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import java.awt.FlowLayout;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.GridLayout;

import javax.sound.midi.MidiDevice.Info;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTextPane;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import entity.Film;

import javax.swing.JRadioButton;
import javax.swing.JPasswordField;
import javax.swing.JList;
import javax.swing.JTable;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.util.ArrayList;

import service.*;
import javax.swing.JScrollBar;
import java.awt.SystemColor;
import java.awt.Font;

public class UFilm {

	private JFrame frame;
	private JTable table_2;
	private JLabel lblL;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					UFilm window = new UFilm();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * @throws IOException 
	 */
	public UFilm() throws IOException {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 * @throws IOException 
	 */
	private void initialize() throws IOException {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.ORANGE);
		frame.setBackground(Color.MAGENTA);
		frame.setBounds(100, 100, 1557, 1000);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		ManagerService m = new ManagerService();
		m.iniFilm(); //create list films from previous file
		m.deleFilm("7");
		ArrayList <Film> f = m.getFilms();
		
		Object[][] data;	
		data = new Object[(f.size())][5];
		
		for(int i = 0; i < f.size(); i++){
			data[i][0] = f.get(i).getId()+"";
			data[i][1] = f.get(i).getName();
			data[i][2] = f.get(i).getDuration()+"min";
			data[i][3] =new ImageIcon(f.get(i).getImage());
			//data[i][3] = f.get(i).get();
			
			String info = f.get(i).getInfo();
		    String information = "<html>";
		    for(int j =1 ; j<info.length()+1; j++){
		    	information = information+info.charAt(j-1);
		    	if(j%39 == 0){
		    		information = information+"<br>";
		    	}
		    }
		    information = information+"</html>";
		    data[i][4] = information;
		    
		}
		
	
		String[] columnNames = {"Film ID",
                "Name",
                "Duration",
                "Image",
                "Infomation"};
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment( SwingConstants.CENTER );
		

		
		
		DefaultTableModel tableModel = new DefaultTableModel(data, columnNames) {
		    @Override
		    public boolean isCellEditable(int row, int column) {
		       //all cells false
		       return false;
		    }
		};
		table_2 = new JTable(tableModel){
			 public String getToolTipText( MouseEvent e )
	            {
	                int row = rowAtPoint( e.getPoint() );
	                int column = columnAtPoint( e.getPoint() );

	                Object value = getValueAt(row, column);
	                return value == null ? null : value.toString();
	            }
            public Class<? extends Object> getColumnClass(int column)
            {
                return getValueAt(1, column).getClass();
            }
        };
		table_2.setFont(new Font("Verdana", Font.PLAIN, 18));
		table_2.setBackground(SystemColor.info);
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(141, 112, 1300, 800);
		frame.getContentPane().add(scrollPane);
		scrollPane.setViewportView(table_2);
		
		 table_2.setRowHeight(260);
		 
		 JLabel lblFilms = new JLabel("Films:");
		 lblFilms.setFont(new Font("Verdana", Font.BOLD, 27));
		 lblFilms.setBounds(51, 43, 187, 43);
		 frame.getContentPane().add(lblFilms);
		 
		 lblL = new JLabel("l2");
		 lblL.setBounds(808, 13, 72, 43);
		 frame.getContentPane().add(lblL);

		 
		 table_2.getColumn("Name").setMinWidth(100);
		 table_2.getColumn("Film ID").setMaxWidth(50);
		 table_2.getColumn("Duration").setMaxWidth(80);
		 
		 
		 table_2.setDefaultRenderer(Object.class, centerRenderer);	 
		 table_2.addMouseListener(new MouseAdapter() {
			  public void mouseClicked(MouseEvent e) {
			    if (e.getClickCount() == 2) {
			      JTable target = (JTable)e.getSource();
			      int row = target.getSelectedRow();
			  	 String fid = table_2.getValueAt(row,0).toString();
			      lblL.setText(fid+"");
			      // do some action if appropriate column
			    }
			  }
			});
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
	}
}
