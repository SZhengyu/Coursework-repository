package View.Film;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;

import service.ManagerService;

public class AlterFilm {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AlterFilm window = new AlterFilm("1");
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AlterFilm(String fid) {
		initialize(fid);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String fid) {
		frame = new JFrame();
		JTextField textFieldName;
		JTextField textFieldDuration;
		frame.setVisible(true);
		frame.setBounds(100, 100, 1058, 721);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblAddingFilm = new JLabel("Altering film "+fid);
		lblAddingFilm.setFont(new Font("Verdana", Font.BOLD, 30));
		lblAddingFilm.setBounds(291, 30, 553, 64);
		frame.getContentPane().add(lblAddingFilm);
		
		JLabel lblName = new JLabel("Name:");
		lblName.setFont(new Font("Verdana", Font.PLAIN, 20));
		lblName.setBounds(74, 120, 67, 30);
		frame.getContentPane().add(lblName);
		
		JLabel lblDuration = new JLabel("Duration:");
		lblDuration.setBounds(45, 206, 96, 30);
		lblDuration.setFont(new Font("Verdana", Font.PLAIN, 20));
		frame.getContentPane().add(lblDuration);
		
		JLabel lblImage = new JLabel("Image:");
		lblImage.setFont(new Font("Verdana", Font.PLAIN, 20));
		lblImage.setBounds(69, 270, 72, 44);
		frame.getContentPane().add(lblImage);
		JLabel lblShowimage = new JLabel();
		lblShowimage.setBounds(515, 120, 429, 410);
		frame.getContentPane().add(lblShowimage);
		JButton btnUpload = new JButton("Upload");
		
		btnUpload.setBounds(164, 283, 113, 27);
		frame.getContentPane().add(btnUpload);
		
		
		
		
		JLabel lblInformation = new JLabel("Information:");
		lblInformation.setFont(new Font("Verdana", Font.PLAIN, 20));
		lblInformation.setBounds(14, 365, 127, 44);
		frame.getContentPane().add(lblInformation);
		
		textFieldName = new JTextField();
		textFieldName.setBounds(164, 123, 236, 27);
		frame.getContentPane().add(textFieldName);
		textFieldName.setColumns(10);
		
		textFieldDuration = new JTextField();
		textFieldDuration.setBounds(164, 211, 140, 27);
		frame.getContentPane().add(textFieldDuration);
		textFieldDuration.setColumns(10);
		
		JTextArea textAreaInformation = new JTextArea();
		textAreaInformation.setBounds(164, 379, 319, 246);
		frame.getContentPane().add(textAreaInformation);
		
		JFileChooser chooser = new JFileChooser();
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				String name = textFieldName.getText();
				String duration = textFieldDuration.getText();
				String info = textAreaInformation.getText();
				String image = chooser.getSelectedFile().getPath();
				
				ManagerService m = new ManagerService();
				m.iniFilm();
				try {
					m.alterFilm(fid,name, duration, image, info);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				frame.setVisible(false);
				MFilm f = new MFilm();

			}
		});
		btnSubmit.setBounds(731, 621, 113, 27);
		frame.getContentPane().add(btnSubmit);
		
		JButton btnBack = new JButton("Back");
		btnBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.setVisible(false);
				MFilm f = new MFilm();
			}
		});
		btnBack.setBounds(872, 621, 113, 27);
		frame.getContentPane().add(btnBack);
		
		
		
		btnUpload.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				 
				    FileNameExtensionFilter filter = new FileNameExtensionFilter(
				        "JPG & GIF Images", "jpg", "gif");
				    chooser.setFileFilter(filter);
				    int returnVal = chooser.showOpenDialog(btnUpload);
				    if(returnVal == JFileChooser.APPROVE_OPTION) {
				      
				    	lblShowimage.setIcon(new ImageIcon(chooser.getSelectedFile().getPath()));
				    }
				    else{
				    	lblShowimage.setText("Wrong choice");
				    }
			}
		});
		
	}
}
