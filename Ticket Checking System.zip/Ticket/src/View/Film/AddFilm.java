package View.Film;

import java.awt.EventQueue;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;

import service.ManagerService;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.swing.JTextArea;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AddFilm {

	private JFrame frame;
	private JTextField textFieldName;
	private JTextField textFieldDuration;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddFilm window = new AddFilm();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AddFilm() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	public void initialize() {
		frame = new JFrame();
		frame.setForeground(new Color(255, 250, 205));
		frame.setBackground(new Color(255, 248, 220));
		frame.setVisible(true);
		frame.getContentPane().setBackground(new Color(255, 250, 205));
		frame.setBounds(100, 100, 1058, 735);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblAddingFilm = new JLabel("Adding film");
		lblAddingFilm.setFont(new Font("Verdana", Font.BOLD, 30));
		lblAddingFilm.setBounds(400, 32, 236, 64);
		frame.getContentPane().add(lblAddingFilm);
		
		JLabel lblName = new JLabel("Name:");
		lblName.setFont(new Font("Verdana", Font.PLAIN, 20));
		lblName.setBounds(65, 120, 123, 30);
		frame.getContentPane().add(lblName);
		
		JLabel lblDuration = new JLabel("Duration:");
		lblDuration.setBounds(32, 206, 117, 30);
		lblDuration.setFont(new Font("Verdana", Font.PLAIN, 20));
		frame.getContentPane().add(lblDuration);
		
		JLabel lblImage = new JLabel("Image:");
		lblImage.setFont(new Font("Verdana", Font.PLAIN, 20));
		lblImage.setBounds(65, 274, 117, 44);
		frame.getContentPane().add(lblImage);
		JLabel lblShowimage = new JLabel();
		lblShowimage.setBounds(515, 120, 429, 410);
		frame.getContentPane().add(lblShowimage);
		JButton btnUpload = new JButton("Upload");
		
		btnUpload.setBounds(164, 283, 113, 27);
		frame.getContentPane().add(btnUpload);
		
		
		
		
		JLabel lblInformation = new JLabel("Information:");
		lblInformation.setFont(new Font("Verdana", Font.PLAIN, 20));
		lblInformation.setBounds(14, 365, 163, 44);
		frame.getContentPane().add(lblInformation);
		
		textFieldName = new JTextField();
		textFieldName.setBounds(164, 123, 236, 27);
		frame.getContentPane().add(textFieldName);
		textFieldName.setColumns(10);
		
		textFieldDuration = new JTextField();
		textFieldDuration.setBounds(164, 211, 140, 27);
		frame.getContentPane().add(textFieldDuration);
		textFieldDuration.setColumns(10);
		
		JTextArea textAreaInformation = new JTextArea();
		textAreaInformation.setBounds(164, 379, 319, 246);
		frame.getContentPane().add(textAreaInformation);
		
		JFileChooser chooser = new JFileChooser();
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				String name = textFieldName.getText();
				String duration = textFieldDuration.getText();
				String info = textAreaInformation.getText();
				String image = chooser.getSelectedFile().getPath();
				
				ManagerService m = new ManagerService();
				m.iniFilm();
				m.addFilm(name, duration, image, info);
				frame.setVisible(false);
				MFilm f = new MFilm();
				f.initialize();

			}
		});
		btnSubmit.setBounds(731, 621, 113, 27);
		frame.getContentPane().add(btnSubmit);
		
		JButton btnBack = new JButton("Back");
		btnBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.setVisible(false);
				MFilm f = new MFilm();
			}
		});
		btnBack.setBounds(872, 621, 113, 27);
		frame.getContentPane().add(btnBack);
		
		
		
		btnUpload.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				 
				    FileNameExtensionFilter filter = new FileNameExtensionFilter(
				        "JPG & GIF Images", "jpg", "gif");
				    chooser.setFileFilter(filter);
				    int returnVal = chooser.showOpenDialog(btnUpload);
				    if(returnVal == JFileChooser.APPROVE_OPTION) {
				      
				    	lblShowimage.setIcon(new ImageIcon(chooser.getSelectedFile().getPath()));
				    }
				    else{
				    	lblShowimage.setText("Wrong choice");
				    }
			}
		});
		

	}
}
