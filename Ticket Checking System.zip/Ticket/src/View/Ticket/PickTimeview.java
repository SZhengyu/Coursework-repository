package View.Ticket;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.SpinnerDateModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import org.omg.CORBA.PUBLIC_MEMBER;

import View.*;
import View.Screen.Screen1_view;
import View.Screen.Screen2_view;
import View.Screen.Screen3_view;
import entity.Schedule;
import service.ManagerService;

public class PickTimeview {

	private JFrame frame;
	private JTable table;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PickTimeview window = new PickTimeview("dsaf");
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PickTimeview(String ffid) {
		initialize(ffid);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String ffid) {
		frame = new JFrame();
		frame.setBounds(100, 100, 1000, 750);
		frame.getContentPane().setBackground(new Color(255, 250, 205));
		frame.getContentPane().setLayout(null);
		
		JLabel lblSchedule = new JLabel("Schedule");
		lblSchedule.setBounds(180, 13, 362, 56);
		frame.getContentPane().add(lblSchedule);
		JLabel wrongLabel = new JLabel();
		 wrongLabel.setBounds(144, 63, 468, 44);
		table = new JTable();
		frame.getContentPane().add(table);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		 JButton btnBack = new JButton("Back");
		 btnBack.addMouseListener(new MouseAdapter() {
		 	@Override
		 	public void mouseClicked(MouseEvent e) {
		 		frame.setVisible(false);
		 		PickFilmview s = new PickFilmview();
		 	}
		 });
		 btnBack.setBounds(828, 562, 113, 27);
		 frame.getContentPane().add(btnBack);
		
		ManagerService m = new ManagerService();
		ArrayList<Schedule> schs = m.getSchs();
		ArrayList<Schedule> tschs = new ArrayList<Schedule>();
		Date now = new Date();
		for(int i = 0; i < schs.size(); i++){
			if(schs.get(i).getFilm().getId() == Integer.parseInt(ffid)){
				if(now.getHours() < schs.get(i).getDate().getHours()){ //here i decrease 10 for easier test=================
					tschs.add(schs.get(i));					
				}
				else if(now.getHours() == schs.get(i).getDate().getHours()){
					if(now.getMinutes() < schs.get(i).getDate().getMinutes()){
						tschs.add(schs.get(i));
					}
				}
			
			}
		}
		if(tschs.isEmpty()){
			wrongLabel.setText("We do not have this film today,Please click back and choose again");
		}
		

		Object data[][] = new Object[(tschs.size())][4];
		for(int i = 0; i < tschs.size(); i++){
			data[i][0] = tschs.get(i).getId()+"";
			data[i][1] = tschs.get(i).getScreen().getType();
			data[i][2] = new SimpleDateFormat("HH:mm").format(tschs.get(i).getDate());
			data[i][3] = tschs.get(i).getScreen().getRest();
		
			}
		
	
		String[] columnNames = {"ID","Screen",
                "Time",
                "Rest"};
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment( SwingConstants.CENTER );
		DefaultTableModel tableModel = new DefaultTableModel(data, columnNames) {
		    @Override
		    public boolean isCellEditable(int row, int column) {
		       //all cells false
		       return false;
		    }
		};
		frame.getContentPane().setLayout(null);
		table = new JTable(tableModel){
            public Class<? extends Object> getColumnClass(int column)
            {
                return getValueAt(0, column).getClass();
            }
        };
		table.setFont(new Font("Verdana", Font.PLAIN, 18));
		table.setBackground(SystemColor.info);
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(90, 118, 662, 382);
		frame.getContentPane().add(scrollPane);
		scrollPane.setViewportView(table);
		
		 table.setRowHeight(100);
		 
		 
		 frame.getContentPane().add(wrongLabel);
		 table.getColumn("ID").setMaxWidth(500);
		 table.getColumn("Rest").setMaxWidth(500);
		 table.getColumn("Time").setMaxWidth(500);
		 table.getColumn("Screen").setMaxWidth(300);
		 table.setDefaultRenderer(Object.class, centerRenderer);	 
		 table.addMouseListener(new MouseAdapter() {
			  public void mouseClicked(MouseEvent e) {
			    if (e.getClickCount() == 2) {
			    	JTable target1 = (JTable)e.getSource();
				     int row = target1.getSelectedRow();
				  	 int schid = Integer.parseInt(table.getValueAt(row,0).toString()) ;
				  	 Schedule s = m.getSch(schid);
				  	 if (s.getScreen().getType() == 1){
				  		 Screen1_view s1 = new Screen1_view(schid);
				  	 }
				  	 else if (s.getScreen().getType() == 2){
				  		 Screen2_view s2 = new Screen2_view(schid);
				  	 }
				  	 else{
				  		Screen3_view s3 = new Screen3_view(schid);
				  	 }
				  	frame.setVisible(false);
			    }
			    }
			});
		 
		 frame.setVisible(true);
	}
}