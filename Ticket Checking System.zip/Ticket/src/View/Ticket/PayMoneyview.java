package View.Ticket;

import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JLabel;

import service.ManagerService;

import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;

public class PayMoneyview {

	private JFrame frame;
	
	/**
	 * @wbp.parser.entryPoint
	 */
	public void paymoney(int type) {
		ManagerService m = new ManagerService();
		
		frame = new JFrame();
		frame.setBounds(100, 100, 1000, 750);
		frame.getContentPane().setBackground(new Color(255, 250, 205));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel money = new JLabel();
		money.setFont(new Font("Lucida Grande", Font.PLAIN, 19));
		money.setBounds(91, 109, 355, 123);
		frame.getContentPane().add(money);
		
		JButton b = new JButton("Finish! Print my ticket");
		b.setBounds(106, 553, 280, 29);
		frame.getContentPane().add(b);
		frame.setVisible(true);
		
		 JButton btnBack = new JButton("Back");
		 btnBack.addMouseListener(new MouseAdapter() {
		 	@Override
		 	public void mouseClicked(MouseEvent e) {
		 		m.getTics().remove(m.getTics().get(m.getTics().size()-1));
		 		m.saveTic();
		 		frame.setVisible(false);
		 		PickFilmview s = new PickFilmview();
		 	}
		 });
		 btnBack.setBounds(824, 554, 113, 27);
		 frame.getContentPane().add(btnBack);
		 
		 String Stype;
		 
		if(type==1){
			money.setText("50% discount! Please pay £8");
			Stype = "Child";
			
		}
		else if(type==2){
			money.setText("Full price! Please pay £16");
			Stype = "Adult";
		}
		else if(type==3){
			money.setText("20% discount! Please pay £12.8");
			Stype = "Senior";
			
		}
		else{
			money.setText("15% discount! Please pay £13.6");
			Stype = "Student";
			
		}
		
		b.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				JButton t = (JButton)e.getSource();
				frame.setVisible(false);
				PrintTicket p = new PrintTicket();
				p.printticket(Stype,type);
				
			}});
		
		
		
	}
	
	

}
