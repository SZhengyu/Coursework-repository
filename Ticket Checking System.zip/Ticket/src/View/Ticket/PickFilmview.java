package View.Ticket;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import View.Film.MFilm;
import entity.Film;
import service.ManagerService;
import test.Administrator;
import test.Welcome;

public class PickFilmview {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PickFilmview window = new PickFilmview();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PickFilmview() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 250, 205));
		frame.setBackground(new Color(255, 250, 205));
		frame.setForeground(new Color(255, 250, 205));
		frame.getContentPane().setForeground(new Color(255, 250, 205));
		frame.setVisible(true);
		frame.setBounds(100, 100, 1000, 750);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JTable table_2;
		JLabel lblL;
		ManagerService m = new ManagerService();
		ArrayList <Film> f = m.getFilms();
		
		Object[][] data;	
		data = new Object[(f.size())][5];
		for(int i = 0; i < f.size(); i++){
			data[i][0] = f.get(i).getId()+"";
			data[i][1] = f.get(i).getName();
			data[i][2] = f.get(i).getDuration()+"min";
			data[i][3] =new ImageIcon(f.get(i).getImage());
			//data[i][3] = f.get(i).get();
			//data[i][4] = f.get(i).getInfo();
			String info = f.get(i).getInfo();
		    String information = "<html>";
		    for(int j =1 ; j<info.length()+1; j++){
		    	information = information+info.charAt(j-1);
		    	if(j%39 == 0){
		    		information = information+"<br>";
		    	}
		    }
		   // System.out.println(information);
		    information = information+"</html>";
		    data[i][4] = information;
			
			}
		
	
		String[] columnNames = {"Film ID",
                "Name",
                "Duration",
                "Image",
                "Infomation"};
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment( SwingConstants.CENTER );
		

		
		
		DefaultTableModel tableModel = new DefaultTableModel(data, columnNames) {
		    @Override
		    public boolean isCellEditable(int row, int column) {
		       //all cells false
		       return false;
		    }
		};
		frame.getContentPane().setLayout(null);
		table_2 = new JTable(tableModel){
            public Class<? extends Object> getColumnClass(int column)
            {
                return getValueAt(1, column).getClass();
            }
        };
		table_2.setFont(new Font("Verdana", Font.PLAIN, 14));
		table_2.setBackground(SystemColor.info);
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(83, 62, 850, 513);
		frame.getContentPane().add(scrollPane);
		scrollPane.setViewportView(table_2);
		
		 table_2.setRowHeight(250);
		 
		 lblL = new JLabel("l2");
		 lblL.setForeground(new Color(255, 250, 205));
		 lblL.setBounds(711, 6, 212, 43);
		 frame.getContentPane().add(lblL);
		 
		 JLabel lblDeleteFilm = new JLabel("Pick a film");
		 lblDeleteFilm.setFont(new Font("Verdana", Font.BOLD, 20));
		 lblDeleteFilm.setBounds(378, 17, 162, 32);
		 frame.getContentPane().add(lblDeleteFilm);
		 
		 JButton btnBack = new JButton("Back");
		 btnBack.addMouseListener(new MouseAdapter() {
		 	@Override
		 	public void mouseClicked(MouseEvent e) {
		 		Welcome w = new Welcome();
				w.welcome();
				frame.setVisible(false);
		 	}
		 });
		 
		 btnBack.setBounds(810, 615, 113, 27);
		 frame.getContentPane().add(btnBack);

		 table_2.getColumn("Name").setWidth(45);
		 table_2.getColumn("Film ID").setMaxWidth(35);
		 table_2.getColumn("Duration").setMaxWidth(60);
		 table_2.getColumn("Image").setWidth(45);
		 table_2.getColumn("Infomation").setMinWidth(160);
		 
		 table_2.setDefaultRenderer(Object.class, centerRenderer);	 
		 table_2.addMouseListener(new MouseAdapter() {
			  public void mouseClicked(MouseEvent e) {
			    if (e.getClickCount() == 2) {
			      JTable target = (JTable)e.getSource();
			      int row = target.getSelectedRow();
			  	  String fid = table_2.getValueAt(row,0).toString();
			  	  ManagerService m = new ManagerService();
			  	  frame.setVisible(false);
			  	  PickTimeview pt = new PickTimeview(fid);
			  	  
			      
			    }
			  }
			});

	}

}
