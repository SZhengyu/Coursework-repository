package View.Ticket;

import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JTextField;

import entity.Ticket;
import service.ManagerService;
import test.Welcome;

import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;

public class ReturnTicketview {
	JFrame frame;
	private JTextField textField;
	
	public ReturnTicketview() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1000, 750);
		frame.getContentPane().setBackground(new Color(255, 250, 205));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setVisible(true);
		
		textField = new JTextField();
		textField.setBounds(280, 105, 130, 26);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblTypeInYour = new JLabel("Type in your Ticket Id: ");
		lblTypeInYour.setFont(new Font("Lucida Grande", Font.PLAIN, 19));
		lblTypeInYour.setBounds(51, 96, 309, 39);
		frame.getContentPane().add(lblTypeInYour);
		
		JButton btnReturnTicket = new JButton("Return Ticket");
		btnReturnTicket.setBounds(469, 105, 117, 29);
		frame.getContentPane().add(btnReturnTicket);
		
		JLabel warnlabel = new JLabel();
		warnlabel.setBounds(55, 192, 355, 41);
		frame.getContentPane().add(warnlabel);
		
		JButton btnBack = new JButton("Back");
		 btnBack.addMouseListener(new MouseAdapter() {
		 	@Override
		 	public void mouseClicked(MouseEvent e) {
		 		Welcome w = new Welcome();
				w.welcome();
				frame.setVisible(false);
		 	}
		 });
		 
		 btnBack.setBounds(810, 615, 113, 27);
		 frame.getContentPane().add(btnBack);
		
		btnReturnTicket.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				JButton t = (JButton)e.getSource();
				ManagerService m = new ManagerService();
				Ticket ticket = m.geTic(textField.getText());
				
                if(ticket.getIdnum().equals(textField.getText())){
                	System.out.println("going to return...");
                	int i = 0;
                	for(i = 0; i < m.getTics().size(); i++){
            			if (m.getTics().get(i).getIdnum().equals(ticket.getIdnum())){
            				System.out.println(i);
            				System.out.println(ticket.getIdnum());
            				break;
            			}	
                	}
                	m.getTics().remove(i);
					m.getSch(ticket.getSchid()).getScreen().reScreen(ticket.getSeatnum());
				    ticket.refound();
				    m.saveTic();
					m.saveSch();
					warnlabel.setText("Successful!");
                }
                else{
                	warnlabel.setText("Unsuccessful! Wrong ticket ID!");
                }
                
				
			}});
	}
}
