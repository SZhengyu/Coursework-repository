package View.Ticket;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;

import javax.swing.JFrame;
import javax.swing.JLabel;

import entity.Ticket;
import service.ManagerService;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.JButton;

public class PickTypeview {

	private JFrame frame;
	private JTextField txtStudentId;
	public int type;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PickTypeview window = new PickTypeview("1");
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PickTypeview(String tickid) {
		initialize(tickid);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String tickid) {
		
		ManagerService m = new ManagerService();
		Ticket ticket = m.geTic(tickid);
		
		frame = new JFrame();
		frame.setBounds(100, 100, 1000, 750);
		frame.getContentPane().setBackground(new Color(255, 250, 205));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		
		JLabel lblFilmname = new JLabel("FilmName: "+m.getSch(ticket.getSchid()).getFilm().getName());
		lblFilmname.setBounds(25, 51, 288, 30);
		lblFilmname.setFont(new Font("Lucida Grande", Font.PLAIN, 19));
		frame.getContentPane().add(lblFilmname);
		
		JLabel lblTime = new JLabel("Time: "+new SimpleDateFormat("HH:mm").format(m.getSch(ticket.getSchid()).getDate()));
		lblTime.setBounds(389, 51, 159, 30);
		lblTime.setFont(new Font("Lucida Grande", Font.PLAIN, 19));
		frame.getContentPane().add(lblTime);
		
		JLabel lblSeatno = new JLabel("SeatNo: "+ticket.getSeatid()+"");
		lblSeatno.setBounds(579, 51, 149, 30);
		lblSeatno.setFont(new Font("Lucida Grande", Font.PLAIN, 19));
		frame.getContentPane().add(lblSeatno);
		
		JRadioButton s1 = new JRadioButton("Child ( 2 to 17 years old )");
		s1.setFont(new Font("Lucida Grande", Font.PLAIN, 19));
		s1.setBounds(50, 160, 335, 23);
		frame.getContentPane().add(s1);
		
		JRadioButton s2 = new JRadioButton("Aldult ( 18 years and older )");
		s2.setFont(new Font("Lucida Grande", Font.PLAIN, 19));
		s2.setBounds(50, 230, 335, 23);
		frame.getContentPane().add(s2);
		
		JRadioButton s3 = new JRadioButton("Senior ( 55 years and older )");
		s3.setFont(new Font("Lucida Grande", Font.PLAIN, 19));
	    s3.setBounds(50, 301, 335, 23);
		frame.getContentPane().add(s3);
		
		JRadioButton s4 = new JRadioButton("Student ( 18 years and older and in full time education )");
		s4.setFont(new Font("Lucida Grande", Font.PLAIN, 19));
		s4.setBounds(50, 370, 560, 23);
		frame.getContentPane().add(s4);
		
		txtStudentId = new JTextField();
		txtStudentId.setBounds(214, 405, 130, 26);
		frame.getContentPane().add(txtStudentId);
		txtStudentId.setColumns(10);
		
		JLabel lblStudentId = new JLabel("Student Id:");
		lblStudentId.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		lblStudentId.setBounds(117, 410, 85, 16);
		frame.getContentPane().add(lblStudentId);
		
		JButton btnOk = new JButton("OK");
		btnOk.setBounds(50, 524, 117, 29);
		frame.getContentPane().add(btnOk);
		/*
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(130, 57, 171, 24);
		lblNewLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 19));
		frame.getContentPane().add(lblNewLabel);
		lblNewLabel.setText(m.getSch(ticket.getSchid()+"").getFilm().getName());
		
		JLabel label = new JLabel("New label");
		label.setBounds(295, 54, 171, 24);
		label.setFont(new Font("Lucida Grande", Font.PLAIN, 19));
		frame.getContentPane().add(label);
		label.setText(new SimpleDateFormat("HH:mm").format(m.getSch(ticket.getSchid()+"").getDate()));
		
		JLabel label_1 = new JLabel("New label");
		label_1.setBounds(517, 54, 171, 24);
		frame.getContentPane().add(label_1);
		label_1.setText(ticket.getSeatid()+"");
		label_1.setFont(new Font("Lucida Grande", Font.PLAIN, 19));*/
		frame.setVisible(true);
		
		 JButton btnBack = new JButton("Back");
		 btnBack.addMouseListener(new MouseAdapter() {
		 	@Override
		 	public void mouseClicked(MouseEvent e) {
		 		m.getTics().remove(m.getTics().get(m.getTics().size()-1));
		 		m.saveTic();
		 		frame.setVisible(false);
		 		PickFilmview s = new PickFilmview();
		 	}
		 });
		 btnBack.setBounds(828, 562, 113, 27);
		 frame.getContentPane().add(btnBack);
		 
		
		btnOk.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				JButton t = (JButton)e.getSource();
				PayMoneyview pay = new PayMoneyview();
				if(s1.isSelected()){
					type =1;
					ticket.setDiscount(0.5);
					ticket.setPrice(8);
					ticket.setType(1);
					m.saveTic();
					pay.paymoney(type);
					frame.setVisible(false);
				}
				else if(s2.isSelected()){
					type =2;
					ticket.setDiscount(0);
					ticket.setPrice(16);
					ticket.setType(2);
					m.saveTic();
					pay.paymoney(type);
					frame.setVisible(false);
				}
				else if(s3.isSelected()){
					type =3;
					ticket.setDiscount(0.8);
					ticket.setPrice(12.8);
					ticket.setType(3);
					m.saveTic();
					pay.paymoney(type);
					frame.setVisible(false);
				}
				else if(s4.isSelected()&&!txtStudentId.getText().equals("")){
					type =4;
					ticket.setDiscount(0.85);
					ticket.setPrice(13.6);
					ticket.setType(4);
					ticket.setStudentid(Integer.parseInt(txtStudentId.getText()));
					m.saveTic();
					pay.paymoney(type);
					frame.setVisible(false);
				}
				
			}});
	}
}
