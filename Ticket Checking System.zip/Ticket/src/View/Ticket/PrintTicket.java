package View.Ticket;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;

import javax.swing.JFrame;
import javax.swing.JLabel;

import View.Screen.Screen1_view;
import View.Screen.Screen2_view;
import View.Screen.Screen3_view;
import entity.Schedule;
import entity.Ticket;
import service.ManagerService;
import test.Welcome;

import javax.swing.JButton;
import javax.swing.JTextField;

public class PrintTicket {
	
	private JFrame frame;
	private JTextField txtType;
	
	/**
	 * @wbp.parser.entryPoint
	 */
	public void printticket(String Stype,int type){
		
		frame = new JFrame();
		frame.setBounds(100, 100, 400, 541);
		frame.getContentPane().setBackground(new Color(255, 250, 205));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setVisible(true);
		
		ManagerService m = new ManagerService();
		
		//only when the ticket have been printed out, the seat closed;
		Ticket ticket = m.getTics().get(m.getTics().size()-1);
		ticket.setPay();
		m.saveTic();
		m.getSch(ticket.getSchid()).getScreen().deScreen(ticket.getSeatnum());
		m.saveSch();
		
		JLabel lblFilmname = new JLabel("FilmName: "+m.getSch(ticket.getSchid()).getFilm().getName());
		lblFilmname.setBounds(25, 120, 288, 30);
		lblFilmname.setFont(new Font("Lucida Grande", Font.PLAIN, 19));
		frame.getContentPane().add(lblFilmname);
		
		JLabel lblTime = new JLabel("Time: "+new SimpleDateFormat("HH:mm").format(m.getSch(ticket.getSchid()).getDate()));
		lblTime.setBounds(25, 200, 159, 30);
		lblTime.setFont(new Font("Lucida Grande", Font.PLAIN, 19));
		frame.getContentPane().add(lblTime);
		
		JLabel lblSeatno = new JLabel("SeatNo: "+ticket.getSeatid()+"");
		lblSeatno.setBounds(189, 280, 149, 30);
		lblSeatno.setFont(new Font("Lucida Grande", Font.PLAIN, 19));
		frame.getContentPane().add(lblSeatno);
		
		JLabel lblNewLabel = new JLabel("Screen: "+m.getSch(ticket.getSchid()).getScreen().type);
		lblNewLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 19));
		lblNewLabel.setBounds(25, 280, 228, 30);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblPrice = new JLabel("Price: "+ticket.getPrice());
		lblPrice.setFont(new Font("Lucida Grande", Font.PLAIN, 19));
		lblPrice.setBounds(25, 360, 235, 30);
		frame.getContentPane().add(lblPrice);
		
		JButton btnBack = new JButton("Done");
		btnBack.setBounds(236, 484, 117, 29);
		frame.getContentPane().add(btnBack);
	
		 btnBack.addMouseListener(new MouseAdapter() {
		 	@Override
		 	public void mouseClicked(MouseEvent e) {
		 		frame.setVisible(false);
		 		Welcome w = new Welcome();
				w.welcome();
		 	}
		 });

		 
		JLabel lblTicketId = new JLabel("Ticket ID: "+ ticket.getIdnum());
		lblTicketId.setFont(new Font("Lucida Grande", Font.PLAIN, 19));
		lblTicketId.setBounds(25, 40, 313, 38);
		frame.getContentPane().add(lblTicketId);
		
		JButton btnBuyMoreOf = new JButton("Buy more of the same film");
		btnBuyMoreOf.setBounds(25, 484, 209, 29);
		frame.getContentPane().add(btnBuyMoreOf);
		
		JLabel lblNewLabel_1 = new JLabel("Type："+ Stype );
		lblNewLabel_1.setFont(new Font("Lucida Grande", Font.PLAIN, 19));
		lblNewLabel_1.setBounds(25, 440, 189, 30);
		frame.getContentPane().add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel(ticket.getStudentid()+"");
		lblNewLabel_2.setFont(new Font("Lucida Grande", Font.PLAIN, 19));
		lblNewLabel_2.setBounds(226, 440, 159, 30);
		frame.getContentPane().add(lblNewLabel_2);
		//System.out.println(type);
		if(type!=4){
			lblNewLabel_2.setVisible(false);
		}
		else{
			lblNewLabel_2.setVisible(true);
		}
		
		btnBuyMoreOf.addMouseListener(new MouseAdapter() {
		 	@Override
		 	public void mouseClicked(MouseEvent e) {
		 		frame.setVisible(false);;
		 		Schedule s = m.getSch(ticket.getSchid());
			  	 if (s.getScreen().getType() == 1){
			  		 Screen1_view s1 = new Screen1_view(ticket.getSchid());
			  	 }
			  	 else if (s.getScreen().getType() == 2){
			  		 Screen2_view s2 = new Screen2_view(ticket.getSchid());
			  	 }
			  	 else{
			  		 Screen3_view s3 = new Screen3_view(ticket.getSchid());
			  	 }
		 	}
		 });
		
		
		
	}
}
