package View.Screen;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;

import View.Film.MFilm;
import View.Ticket.PickFilmview;
import View.Ticket.PickTypeview;
import entity.Schedule;
import entity.Screen;
import entity.Ticket;
import service.ManagerService;

import java.awt.Color;
import javax.swing.JLabel;

public class Screen1_view {

	protected static final String JButton = null;
	JFrame frame;

	/**
	 * Launch the application.
	 */
	/**public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Screen1_view window = new Screen1_view(new int[3]);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the application.
	 */
	public Screen1_view(int a) {
		initialize(a);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(int sch) {
		frame = new JFrame();
		
		frame.getContentPane().setBackground(new Color(255, 250, 205));
		frame.setBounds(100, 100, 892, 697);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel warnlabel = new JLabel();
		warnlabel.setBounds(28, 550, 355, 41);
		frame.getContentPane().add(warnlabel);
		
		JButton btnNewButton = new JButton("Screen");
		btnNewButton.setBounds(216, 596, 421, 41);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblE = new JLabel("D");
		lblE.setFont(new Font("Lucida Grande", Font.PLAIN, 19));
		lblE.setBounds(848, 85, 61, 16);
		frame.getContentPane().add(lblE);
		
		JLabel lblD = new JLabel("C");
		lblD.setFont(new Font("Lucida Grande", Font.PLAIN, 19));
		lblD.setBounds(848, 170, 61, 16);
		frame.getContentPane().add(lblD);
		
		JLabel lblC = new JLabel("B");
		lblC.setFont(new Font("Lucida Grande", Font.PLAIN, 19));
		lblC.setBounds(848, 261, 61, 16);
		frame.getContentPane().add(lblC);
		
		JLabel lblB = new JLabel("A");
		lblB.setFont(new Font("Lucida Grande", Font.PLAIN, 19));
		lblB.setBounds(848, 355, 61, 16);
		frame.getContentPane().add(lblB);
		
		JButton btnBack = new JButton("Back");
		btnBack.setBounds(733, 602, 117, 29);
		frame.getContentPane().add(btnBack);
		 btnBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				JButton t = (JButton)e.getSource();
				PickFilmview window = new PickFilmview();
			}});
		
		ManagerService m = new ManagerService();
		Screen screen = m.getSch(sch).getScreen();
		
		JButton b[] = new JButton[32];
		int temp = 0;
		int q = 751,  w= 67, e = 70, r = 61;
		for(int i = 0; i<32; i++){
			temp = i%8+1;
			b[i] = new JButton(temp+"");
			b[i].setName(i+"");
			b[i].setBounds(q,w,e,r);
			if (temp == 4){
				q = q - 200;
			}
			else{
				q = q-84;
			}
			if (temp == 8){
				q = 751;
				w = w+90;
			}
			frame.getContentPane().add(b[i]);
		}
		
		for(int i=0; i < screen.getSeat().length; i++){
			if(screen.getSeat()[i] == 0){
				b[i].setBackground(new Color(0, 255, 127));
				b[i].setOpaque(true);
				b[i].setBorderPainted(false);
			}
			else{
				//System.out.println(i);
			}
				
		}
		frame.setVisible(true);

		
		for(int i = 0; i<32; i++){
			b[i].addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					JButton t = (JButton)e.getSource();
					int posi = Integer.parseInt(t.getName());
					if (m.getSch(sch).getScreen().getSeat()[posi] == 0){
						//把编号变成几排几座
						int a = posi/8;
						int num = posi%8+1;
						System.out.println(posi);
						String row;
						if (a==3){
							row = "A";
						}
						else if (a==2){
							row = "B";
						}
						else if(a==1){
							row = "C";
						}
						else{
							row = "D";
						}
						System.out.println(row+" "+num);
						Ticket tii = new Ticket(sch, row+num, posi);
						m.addTic(sch,tii);
						m.saveTic();
						frame.setVisible(false);
						PickTypeview  pickTypeview = new PickTypeview(m.getTics().get(m.getTics().size()-1).getIdnum());
					}
					else{
						warnlabel.setText("This seat has already been booked by other people");
					}	
				}
			});
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}

