package service;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.TableColumn;

import View.Ticket.PickFilmview;
import entity.Ticket;
import test.Administrator;
import test.Welcome;

public class Report {
	JFrame frame;
	private JTable table;
	
	public Report() {
		initialize();
	}
	
	public void initialize(){
		frame = new JFrame();
		frame.setBounds(100, 100, 1000, 750);
		frame.getContentPane().setBackground(new Color(255, 250, 205));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setVisible(true);
		
		ManagerService m = new ManagerService();
		
		/* 
         * 设置JTable的列名 
         */  
        String[] columnNames =  
        { "Film", "Sold Number", "Child", "Adult", "Senior", "Student" };  
        
        int count;
        int total=0;
        int c=0;
        int ad=0;
        int s=0;
        int st=0;
        
        Object[][] obj = new Object[m.getFilms().size()+2][6];  
        for (int i = 0; i < m.getFilms().size(); i++)  
        {  
            for (int j = 0; j < 6; j++)  
            {  
                switch (j)  
                {  
                case 0:  
                    obj[i][j] = m.getFilms().get(i).getName();  
                    break;  
                case 1:  
                	count = 0;
                	for(int a =0;a<m.getTics().size();a++){
                		Ticket ticket = m.getTics().get(a);
                		if(m.getFilms().get(i).getName().equals(m.getSch(ticket.getSchid()).getFilm().getName())){
                			if(m.getTics().get(a).isPay()){
                    			count++;
                    			System.out.println("name:"+ m.getFilms().get(i).getName());
                    			System.out.println("screen:"+ticket.getSchid());
                    			System.out.println("number:"+ticket.getIdnum());
                    			total++;
                    		}
                		}
                	}
                    obj[i][j] = count;  
                    break;  
                case 2:  
                	count = 0;
                	for(int a =0;a<m.getTics().size();a++){
                		Ticket ticket = m.getTics().get(a);
                		if(m.getFilms().get(i).getName().equals(m.getSch(ticket.getSchid()).getFilm().getName())){
                			if(m.getTics().get(a).isPay()){
                				if(ticket.getType()==1){
                					count++;
                					c++;
                				}
                    		}
                		}
                	}
                    obj[i][j] = count ;  
                    break;  
                case 3:  
                	count = 0;
                	for(int a =0;a<m.getTics().size();a++){
                		Ticket ticket = m.getTics().get(a);
                		if(m.getFilms().get(i).getName().equals(m.getSch(ticket.getSchid()).getFilm().getName())){
                			if(m.getTics().get(a).isPay()){
                				if(ticket.getType()==2){
                					count++;
                					ad++;
                				}
                    		}
                		}
                	}
                    obj[i][j] = count ;  
                    break;  
                case 4:  
                	count = 0;
                	for(int a =0;a<m.getTics().size();a++){
                		Ticket ticket = m.getTics().get(a);
                		if(m.getFilms().get(i).getName().equals(m.getSch(ticket.getSchid()).getFilm().getName())){
                			if(m.getTics().get(a).isPay()){
                				if(ticket.getType()==3){
                					count++;
                					s++;
                				}
                    		}
                		}
                	}
                    obj[i][j] = count ;  
                    break;  
                case 5:  
                	count = 0;
                	for(int a =0;a<m.getTics().size();a++){
                		Ticket ticket = m.getTics().get(a);
                		if(m.getFilms().get(i).getName().equals(m.getSch(ticket.getSchid()).getFilm().getName())){
                			if(m.getTics().get(a).isPay()){
                				if(ticket.getType()==4){
                					count++;
                					st++;
                				}
                    		}
                		}
                	}
                    obj[i][j] = count ;  
                    break;  
                }  
            }  
        }  
        
        obj[m.getFilms().size()][0] = "TOTAL";
        obj[m.getFilms().size()][1] = total;
        obj[m.getFilms().size()][2] = c;
        obj[m.getFilms().size()][3] = ad;
        obj[m.getFilms().size()][4] = s;
        obj[m.getFilms().size()][5] = st;
          
        obj[m.getFilms().size()+1][0] = "TURNOVER";
        double money = c*8+ad*16+s*12.8+st*13.6;
        obj[m.getFilms().size()+1][1] = "£"+money;
        obj[m.getFilms().size()+1][2] = "£"+c*8;
        obj[m.getFilms().size()+1][3] = "£"+ad*16;
        obj[m.getFilms().size()+1][4] = "£"+s*12.8;
        obj[m.getFilms().size()+1][5] = "£"+st*13.6;
        /* 
         * JTable的其中一种构造方法 
         */  
        JTable table = new JTable(obj, columnNames);  
        /* 
         * 设置JTable的列默认的宽度和高度 
         */  
        TableColumn column = null;  
        int colunms = table.getColumnCount();  
        table.setRowHeight(70);
        for(int i = 0; i < colunms; i++)  
        {  
            column = table.getColumnModel().getColumn(i);  
            /*将每一列的默认宽度设置为200*/  
            column.setPreferredWidth(100);  

        }  
        /* 
         * 设置JTable自动调整列表的状态，此处设置为关闭 
         */  
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);  
        table.setFont(new Font("Verdana", Font.PLAIN, 16));
        /*用JScrollPane装载JTable，这样超出范围的列就可以通过滚动条来查看*/  
        JScrollPane scroll = new JScrollPane(table);  
        scroll.setBounds(76, 62, 700, 513);
        
        JButton btnBack = new JButton("Back");
		 btnBack.addMouseListener(new MouseAdapter() {
		 	@Override
		 	public void mouseClicked(MouseEvent e) {
		 		Administrator window = new Administrator();
				frame.setVisible(false);
		 	}
		 });
		 
		 btnBack.setBounds(824, 554, 113, 27);
		 frame.getContentPane().add(btnBack);
   
		 frame.getContentPane().add(scroll);
		 frame.getContentPane().add(btnBack);
        
	}
}
