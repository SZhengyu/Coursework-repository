package service;

import java.awt.image.BufferedImage;
import java.io.*;
import java.text.DecimalFormat;
import java.util.*;

import javax.imageio.ImageIO;

import entity.*;
// the most important class in this system, containing most functions.
public class ManagerService {
	ArrayList <Film> films;// to hold the information during the process
	ArrayList <Schedule> schedules;
	ArrayList <Ticket> tickets;
	 
	public ManagerService(){
		this.schedules = new ArrayList<Schedule>();
		this.iniSch();// when new this class, manager service, reading all the information from file(txt, image, ser....)
		this.iniFilm();
		this.iniTic();
	}
	
	public void saveall(){
		this.saveFilm(films); // save the all information in file
		this.saveSch();
		this.saveTic();
	}
	
	
	
	//film**************************************************************************** 
	public ArrayList<Film> getFilms() { // all films are stored in arraylist named films, this function is to return all films
		return films;
	}

	public void iniFilm(){ // read all films information from file
		this.films = new ArrayList <Film>();
		String a;
		String filminfo[] = new String[5];	
	    try {  
	    	BufferedReader content = new BufferedReader(new FileReader("src/resources/films/f.txt"));
	    	while ((a = content.readLine())!= null){ 		
	    		filminfo = a.split("\t");
	    		Film f = new Film(filminfo[0],filminfo[1],filminfo[2],filminfo[3],filminfo[4]);
	    		films.add(f);	    		
	    	}
	        content.close();
	    } catch (Exception e) {  
	        e.printStackTrace();  
	       }	
	}
	
	public void saveFilm(ArrayList <Film> films){
		String temp;
		try{
			BufferedWriter content = new BufferedWriter(new FileWriter("src/resources/films/f.txt"));
			for (int i =0 ; i < films.size() ; i++){
				temp = films.get(i).getId() +"\t"+films.get(i).getName()+"\t"+films.get(i).getDuration()+"\t"
							+films.get(i).getImage()+"\t"+films.get(i).getInfo();
				content.write(temp);
				content.newLine();
				
			}
			content.close();
			
		}catch (Exception e) {  
	        e.printStackTrace();  
	       }
		this.iniFilm();
	}
	
	public void addFilm(String name, String duration, String image, String info) { // adding a new film to arraylist
		String id;
		id = (films.get(films.size()-1).getId()+1)+"";
		BufferedImage im;
		try {
			im = ImageIO.read(new File(image));
			String path;
			path = "src/resources/films/image/film" + id +".jpg";
			ImageIO.write(im, "jpg", new File(path));
			Film f = new Film(id,name,duration,path,info);
			films.add(f);
			this.saveFilm(films);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}
	
	public void deleFilm(String id){
		for(int i = 0; i < films.size(); i++){
			if (films.get(i).getId() == Integer.parseInt(id)){
				films.remove(i);
				String path = "src/resources/films/image/film" + id +".jpg";
				File file = new File(path); 
				file.delete();
				break;
			}		
		}
		this.saveFilm(films);
	}
	
	public Film getFilm(String id){ // using film id to find and return that film
		for(int i = 0; i < films.size(); i++){
			if (films.get(i).getId() == Integer.parseInt(id)){
				
				return films.get(i);
			}		
		}
		return films.get(0);
	}
	
	public void alterFilm(String id,String name, String duration, String image, String info) throws IOException{
		for(int i = 0; i < films.size(); i++){
			if (films.get(i).getId() == Integer.parseInt(id)){
				films.get(i).setDuration(Integer.parseInt(duration));
				BufferedImage im = ImageIO.read(new File(image));
				String path;
				path = "src/resources/films/image/film" + id +".jpg";
				ImageIO.write(im, "jpg", new File(path));
				films.get(i).setName(name);
				films.get(i).setInfo(info);
 				break;
			}
			
		
		}
		this.saveFilm(films);
	}

	// schedule*****************************************************************
	public ArrayList<Schedule> getSchs() {
		return schedules;
	}
	
	public void addSch(Schedule sch){
		if(!schedules.isEmpty()){
			sch.setId((schedules.get(schedules.size()-1).getId())+1);
			schedules.add(sch);
		}
		else{
			sch.setId(0);
			schedules.add(sch);
		}
			
		
	}
	
	
	public Schedule getSch(int id){
		for(int i = 0; i < schedules.size(); i++){
			if (schedules.get(i).getId() == id){
				
				return schedules.get(i);
			}		
		}
		return schedules.get(0);
	
	}
	
	public void saveSch(){
		try {
			ObjectOutputStream obj =new ObjectOutputStream(new FileOutputStream(new File("src/resources/sch.ser")));
			obj.writeObject(this.schedules);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void iniSch(){
		try {
			 FileInputStream fis=new FileInputStream("src/resources/sch.ser");
		        ObjectInputStream ois=new ObjectInputStream(fis);
				schedules=(ArrayList<Schedule>)ois.readObject();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void deleSch(String id){
		for(int i = 0; i < schedules.size(); i++){
			if (schedules.get(i).getId() == Integer.parseInt(id)){
				schedules.remove(i);
				this.saveSch();
			}		
		}
	
	}
	
	
	// ticket *******************************************************************
	
	public ArrayList<Ticket> getTics() {
		return tickets;
	}
	
	public Ticket geTic(String idnum){
		for(int i = 0; i < tickets.size(); i++){
			//if (tickets.get(i).getId() == Integer.parseInt(id)){
			if (tickets.get(i).getIdnum().equals(idnum)){
				//System.out.println("here "+i);
				return tickets.get(i);
			}		
			else{
				//System.out.println("");
			}
		}
		return tickets.get(0);
	
	}
	
	public void addTic(int sch, Ticket tic){
		if(!tickets.isEmpty()){
			//tic.setId((tickets.get(tickets.size()-1).getId())+1);
			DecimalFormat dfInt=new DecimalFormat("00");
			//filmid+screen+seatnum+
			String sInt1 = dfInt.format(this.getSch(sch).getFilm().getId());
			String sInt2 = dfInt.format(this.getSch(sch).getId());
			String sInt3 = dfInt.format(this.getSch(sch).getScreen().getType());
			String sInt4 = dfInt.format(tic.getSeatnum());
			String s = sInt1 + sInt2 + sInt3 + sInt4;
			System.out.println(s);
			String[] st = s.split("");
			String n = "";
			for(int i=0;i<st.length;i++){
				int a = Integer.parseInt(st[i]);
				st[i] = Integer.toString(a%4 + 1);
				n = n+st[i];
			}
			tic.setIdnum(n);
			tickets.add(tic);
			System.out.println(tic.getIdnum());
		}
		else{
			tic.setIdnum("0");
		    tickets.add(tic);
		}		
	}
	
	public void saveTic(){
		try {
			ObjectOutputStream obj =new ObjectOutputStream(new FileOutputStream(new File("src/resources/tic.ser")));
			obj.writeObject(this.tickets);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void iniTic(){
		try {
			 FileInputStream fis=new FileInputStream("src/resources/tic.ser");
		        ObjectInputStream ois=new ObjectInputStream(fis);
				this.tickets=(ArrayList<Ticket>)ois.readObject();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("1233");
			this.tickets = new ArrayList<Ticket>();
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
