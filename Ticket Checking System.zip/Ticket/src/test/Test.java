package test;

import java.io.IOException;

import entity.Screen;
import service.*;

public class Test {

	public static void main(String[] args) throws IOException {
		Welcome w = new Welcome();
		w.welcome();
		//for(int i=0; i<m.getSchs().size(); i++){
			//System.out.println(m.getSchs().get(i).getFilm().getName());
		//}
		

		
	}

}
