package test;

import java.util.Scanner;

import entity.Ticket;
import service.ManagerService;

public class CheckTicket {
	
	public static void main(String[] args){
		
		while(true){
			ManagerService m = new ManagerService();
			Scanner sc= new Scanner(System.in);
			System.out.println("Please input your Ticket Number:");
		    
			//***change to get ticket number from port***
			String tNo = sc.nextLine();

		    //check the film of the ticket
		    Ticket ticket = m.geTic(tNo);
		    
		    if(ticket.getIdnum().equals(tNo)){ //ticket exist
		    	if(ticket.getType()!=4){ //not student
		    		//**maybe send a 1 to the port and turn L1 on**
		    		
		    		int screen = m.getSch(ticket.getSchid()).getScreen().type;
		    		//***change to send the screen to the port***
		        	System.out.println("Screen "+screen+":");
		        	
		    		String film = m.getSch(ticket.getSchid()).getFilm().getName();
		    		//***change to send the film name to the port***
		        	System.out.println(film);
		    	}
		    	else{
		    		//**maybe send a 0 to the port and turn L2 on**
		    		System.out.println("Please wait..");
		    		int screen = m.getSch(ticket.getSchid()).getScreen().type;
		    		//***change to send the screen to the port***
		        	System.out.println(screen);
		        	
		    		String film = m.getSch(ticket.getSchid()).getFilm().getName();
		    		//***change to send the film name to the port***
		        	System.out.println(film);
		    		
		    	}
	        	
	        }
	        else{
	        	System.out.println("Wrong ticket ID!");
	        }
			
		}
		
	}

}
