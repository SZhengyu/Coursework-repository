package test;

import java.awt.Color;
import java.io.IOException;

import javax.swing.JFrame;

import service.ManagerService;
import service.Report;

import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JLabel;

import View.Film.MFilm;
import View.Schedule.Scheduleview;
import View.Ticket.PickFilmview;
import View.Ticket.ReturnTicketview;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Welcome {

	/**
	 * @wbp.parser.entryPoint
	 */
	public void welcome() {
		JFrame frame;
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Lucida Grande", Font.PLAIN, 19));
		frame.setBounds(100, 100, 1000, 750);
		frame.getContentPane().setBackground(new Color(255, 250, 205));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		JButton b3 = new JButton("Buy Tickets");
		b3.setFont(new Font("Lucida Grande", Font.PLAIN, 38));
		b3.setBounds(242, 261, 472, 76);
		frame.getContentPane().add(b3);
		
		JButton b4 = new JButton("Return Tickets");
		b4.setFont(new Font("Lucida Grande", Font.PLAIN, 38));
		b4.setBounds(242, 411, 472, 82);
		frame.getContentPane().add(b4);
		
		
		
		JLabel lblWelcomeToOur = new JLabel("Welcome to our Self-Service ticketing kiosk for cinemas!!!");
		lblWelcomeToOur.setFont(new Font("Lucida Grande", Font.PLAIN, 24));
		lblWelcomeToOur.setBounds(120, 115, 732, 49);
		frame.getContentPane().add(lblWelcomeToOur);
		
		JButton b6 = new JButton("Administrator entrance");
		b6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		b6.setBounds(680, 624, 223, 36);
		frame.getContentPane().add(b6);
		
		frame.setVisible(true);
		
		ManagerService m = new ManagerService();
		m.iniSch();
		
		
		b3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				JButton t = (JButton)e.getSource();
				PickFilmview window = new PickFilmview();
				frame.setVisible(false);
			}});
		
		b4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				JButton t = (JButton)e.getSource();
				ReturnTicketview window = new ReturnTicketview();
				frame.setVisible(false);
			}});
		
		b6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				JButton t = (JButton)e.getSource();
				Administrator window = new Administrator();
				frame.setVisible(false);
			}});
		
		
		
	}
}
