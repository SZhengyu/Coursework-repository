import java.util.Scanner;

public class MainTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SimpleCommRxTx.Start();
		Scanner sc= new Scanner(System.in);
        String t = sc.nextLine();
        while(t.equals("next")){
        	SimpleCommRxTx.Start();
        	 t = sc.nextLine();
        }
        
	}

}
