/*
 * Based on SimpleWrite.java provided by Java Sun
 * Updated by Matthew Tang @QMUL 7 May 2017.
 * You need to have RXTX installed with Java
 * Link 1: http://rxtx.qbang.org/wiki/index.php/Main_Page
 * Link 2: http://fizzed.com/oss/rxtx-for-java
 */
import java.io.*;
import java.util.*;

import entity.Ticket;
import gnu.io.*;
import service.ManagerService; 

public class SimpleCommRxTx {
    static CommPortIdentifier portId;
    static CommPort com;
    static SerialPort ser;

    public static void Start() {
        try {
			// TODO: identify the COM port from Windows' control panel
            portId = CommPortIdentifier.getPortIdentifier("COM5");

            com = portId.open("MCS51COM", 2000);
            ser = (SerialPort)com;
            ser.setSerialPortParams(9600, SerialPort.DATABITS_8, 
                                    SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);
        } catch (Exception e){
            e.printStackTrace(System.out);
        }

        ManagerService m = new ManagerService();
        
        try {
			// Test RX: display 8-bit ID received
        	
        	String tNo = "";
            InputStream comIn = ser.getInputStream();
            for (int i = 0; i < 8; i++){
                while (comIn.available() == 0);
                char c = (char)comIn.read();
                tNo = tNo+""+c;
                System.out.print(c);
            }
            comIn.close(); 
         // Test TX: send out chars to 8051
            Ticket ticket = m.geTic(tNo);
            String[] film;
            for(int i=0; i<16;i++){
            	film[i]=" ";
            }
            
            char screen = '0';
            if(ticket.getIdnum().equals(tNo)){ //ticket exist
            	
		    	if(ticket.getType()!=4){ //not student
		    		//**maybe send a 1 to the port and turn L1 on**
		            OutputStream comOut = ser.getOutputStream();
		            comOut.write('0'); 
		            
		    		screen = (char) m.getSch(ticket.getSchid()).getScreen().type;
		    		//***change to send the screen to the port***
		        	//System.out.println("Screen "+screen+":");
		        	
		    		String spfilm = m.getSch(ticket.getSchid()).getFilm().getName();
		    		String[] sp = spfilm.split("");
		    		for(int i=0;i<sp.length;i++){
		    			film[i] = sp[i];
		    		}
		    		//***change to send the film name to the port***
		        	//System.out.println(film);
		    	}
		    	else{
		    		//**maybe send a 0 to the port and turn L2 on**
		            OutputStream comOut = ser.getOutputStream();
		            comOut.write('1'); 
		            
		            Scanner sc= new Scanner(System.in);
		            String pNo = sc.nextLine();
		            if(pNo.equals("1111")){
		            	 comOut.write('T');
		            }else{
		            	comOut.write('F');
		            }
		            
		    		//System.out.println("Please wait..");
		            screen = (char) m.getSch(ticket.getSchid()).getScreen().type;
		    		//***change to send the screen to the port***
		        	//System.out.println(screen);
		        	
		            String spfilm = m.getSch(ticket.getSchid()).getFilm().getName();
		    		String[] sp = spfilm.split("");
		    		for(int i=0;i<sp.length;i++){
		    			film[i] = sp[i];
		    		}
		    		//***change to send the film name to the port***
		        	//System.out.println(film);
		    		
		    	}
	        	
	        }
	        else{
	        	comOut.write('F');
	        	//System.out.println("Wrong ticket ID!");
	        }
            
 
           
            
            comOut.write('S');
            comOut.write(' ');
            comOut.write('C');
            comOut.write('R');
            comOut.write('E');
            comOut.write('E');
            comOut.write('N');
            comOut.write(screen);
            
            comOut.write(':');
            
            for(int b=0;b<100;b++){
            comOut.write(film[0]);
            comOut.write(film[1]);
            comOut.write(film[2]);
            comOut.write(film[3]);
            comOut.write(film[4]);
            comOut.write(film[5]);
            comOut.write(film[6]);
            comOut.write(film[7]);
            comOut.write(film[8]);
            comOut.write(film[9]);
            comOut.write(film[10]);
            comOut.write(film[11]);
            comOut.write(film[12]);
            comOut.write(film[13]);
            comOut.write(film[14]);
            comOut.write(film[15]);
            }
			// close the streams
          
            comOut.close();          
        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
		// close the port
       ser.close(); 
    }
    
}
