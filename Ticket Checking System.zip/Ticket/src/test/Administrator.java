package test;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;

import View.Film.MFilm;
import View.Schedule.Scheduleview;
import View.Schedule.showschview;
import View.Ticket.PickFilmview;
import service.Report;
import javax.swing.JLabel;

public class Administrator {
	
	JFrame frame;
	
	public Administrator(){
		initial();
	}

	private void initial() {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Lucida Grande", Font.PLAIN, 19));
		frame.setBounds(100, 100, 1000, 750);
		frame.getContentPane().setBackground(new Color(255, 250, 205));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton b1 = new JButton("Edit the Film");
		b1.setFont(new Font("Lucida Grande", Font.PLAIN, 19));
		b1.setBounds(292, 200, 312, 71);
		frame.getContentPane().add(b1);
				
		JButton b2 = new JButton("Edit the Schedule");
		b2.setFont(new Font("Lucida Grande", Font.PLAIN, 19));
		b2.setBounds(292, 315, 312, 71);
		frame.getContentPane().add(b2);
		
		JButton b5 = new JButton("Report");
		b5.setFont(new Font("Lucida Grande", Font.PLAIN, 19));
		b5.setBounds(292, 430, 312, 71);
		frame.getContentPane().add(b5);
		
		JButton btnBack = new JButton("Back");
		btnBack.setBounds(733, 602, 117, 29);
		frame.getContentPane().add(btnBack);
		
		JLabel lblNewLabel = new JLabel("Management System");
		lblNewLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 19));
		lblNewLabel.setBounds(118, 82, 288, 63);
		frame.getContentPane().add(lblNewLabel);

		
		 btnBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				JButton t = (JButton)e.getSource();
				Welcome w = new Welcome();
				w.welcome();
				frame.setVisible(false);
			}});

		 frame.setVisible(true);
		
		b1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				JButton t = (JButton)e.getSource();
				MFilm window = new MFilm();
				frame.setVisible(false);
			}});
		
		b2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				JButton t = (JButton)e.getSource();
				showschview window = new showschview();
				frame.setVisible(false);
			}});
		
		b5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				JButton t = (JButton)e.getSource();
				Report window = new Report();
				frame.setVisible(false);
			}});
		
	}
}
